import React from 'react';
import { 
  Database, 
  Filter, 
  CheckSquare, 
  Sliders, 
  Cpu, 
  Network, 
  AlertTriangle, 
  FileCheck2,
  ChevronRight,
  ArrowRight
} from 'lucide-react';

export default function WorkflowDiagram() {
  const steps = [
    {
      id: 1,
      name: "Healthcare Dataset",
      subtitle: "Kaggle Clinical Cohort",
      icon: Database,
      color: "from-blue-500 to-blue-600",
      textColor: "text-blue-600",
      borderColor: "border-blue-200 hover:border-blue-400",
      description: "Patient profile records including age, gender, symptoms, vitals & test results."
    },
    {
      id: 2,
      name: "Data Preprocessing",
      subtitle: "Clean & Format",
      icon: Filter,
      color: "from-indigo-500 to-indigo-600",
      textColor: "text-indigo-600",
      borderColor: "border-indigo-200 hover:border-indigo-400",
      description: "Deduplication, missing-value imputation, data typing, and categorical encoding."
    },
    {
      id: 3,
      name: "Feature Selection",
      subtitle: "Dimensionality Focus",
      icon: CheckSquare,
      color: "from-purple-500 to-purple-600",
      textColor: "text-purple-600",
      borderColor: "border-purple-200 hover:border-purple-400",
      description: "Filtering salient biological attributes (Age, Fever, Dyspnea, BP, Cholesterol)."
    },
    {
      id: 4,
      name: "Feature Standardization",
      subtitle: "StandardScaler (Z-Score)",
      icon: Sliders,
      color: "from-fuchsia-500 to-fuchsia-600",
      textColor: "text-fuchsia-600",
      borderColor: "border-fuchsia-200 hover:border-fuchsia-400",
      description: "Zero-mean and unit-variance scaling to avoid Euclidean metric distortion."
    },
    {
      id: 5,
      name: "DBSCAN Algorithm",
      subtitle: "Density-Based Engine",
      icon: Cpu,
      color: "from-blue-600 to-indigo-700",
      textColor: "text-blue-700",
      borderColor: "border-blue-300 hover:border-blue-500",
      description: "Evaluating eps-neighborhoods and MinPts density connectivity."
    },
    {
      id: 6,
      name: "Clustering",
      subtitle: "Dense Subpopulations",
      icon: Network,
      color: "from-teal-500 to-emerald-600",
      textColor: "text-emerald-600",
      borderColor: "border-emerald-200 hover:border-emerald-400",
      description: "Cohesive clinical cohorts (Respiratory, Cardiometabolic, Asthma, Baseline)."
    },
    {
      id: 7,
      name: "Outlier Detection",
      subtitle: "Isolated Noise Points",
      icon: AlertTriangle,
      color: "from-amber-500 to-orange-600",
      textColor: "text-orange-600",
      borderColor: "border-amber-200 hover:border-amber-400",
      description: "Points residing outside dense clusters flagged with Cluster ID = -1."
    },
    {
      id: 8,
      name: "Potential Unusual Cases",
      subtitle: "Decision Support Alerts",
      icon: FileCheck2,
      color: "from-rose-500 to-red-600",
      textColor: "text-rose-600",
      borderColor: "border-rose-200 hover:border-rose-400",
      description: "Clinically non-conforming cases flagged for specialized expert medical review."
    }
  ];

  return (
    <div className="w-full bg-white rounded-2xl p-6 sm:p-8 shadow-xs border border-slate-200">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-blue-600 bg-blue-50 px-2.5 py-1 rounded-full border border-blue-200">
            End-to-End ML Pipeline
          </span>
          <h3 className="text-xl sm:text-2xl font-bold text-slate-800 mt-2">
            DBSCAN Anomaly Detection Workflow
          </h3>
          <p className="text-sm text-slate-500 mt-1">
            Systematic progression from raw healthcare observations to flagged atypical cases.
          </p>
        </div>
      </div>

      {/* Grid of connected cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 relative">
        {steps.map((step, idx) => {
          const Icon = step.icon;
          return (
            <div 
              key={step.id} 
              className={`relative flex flex-col p-4 rounded-xl border bg-slate-50/50 hover:bg-white transition-all duration-200 shadow-xs hover:shadow-md ${step.borderColor} group`}
            >
              <div className="flex items-center justify-between mb-3">
                <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${step.color} flex items-center justify-center text-white shadow-xs group-hover:scale-105 transition-transform`}>
                  <Icon className="w-5 h-5" />
                </div>
                <div className="flex items-center gap-1">
                  <span className="text-xs font-bold text-slate-400">Step {step.id}</span>
                  {idx < steps.length - 1 && (
                    <ChevronRight className="w-4 h-4 text-slate-300 hidden lg:block" />
                  )}
                </div>
              </div>

              <h4 className={`text-sm font-bold ${step.textColor} mb-0.5`}>
                {step.name}
              </h4>
              <p className="text-xs font-semibold text-slate-700 mb-2">
                {step.subtitle}
              </p>
              <p className="text-xs text-slate-500 leading-relaxed mt-auto">
                {step.description}
              </p>

              {/* Connected Arrow Indicator for mobile/tablet */}
              {idx < steps.length - 1 && (
                <div className="lg:hidden flex justify-center mt-3 pt-2 border-t border-slate-100 text-slate-300">
                  <ArrowRight className="w-4 h-4 rotate-90 sm:rotate-0" />
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Workflow Summary Callout */}
      <div className="mt-8 p-4 rounded-xl bg-gradient-to-r from-blue-50 via-indigo-50 to-purple-50 border border-blue-100 flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-start gap-3">
          <div className="p-2 bg-blue-600 text-white rounded-lg shrink-0 mt-0.5">
            <Cpu className="w-4 h-4" />
          </div>
          <div>
            <h5 className="text-xs font-bold text-slate-800 uppercase tracking-wide">
              Autonomous Anomaly Identification Logic
            </h5>
            <p className="text-xs text-slate-600 mt-0.5">
              Unlike supervised models that need prior labels of hundreds of distinct rare diseases, DBSCAN isolates points that lack local neighborhood density (&lt; MinPts points within radius &epsilon;), effectively capturing previously uncatalogued multi-symptom anomalies.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
