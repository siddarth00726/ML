import React, { useState, useEffect, useMemo, useCallback } from 'react';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import DisclaimerBanner from './components/DisclaimerBanner';

import HomePage from './pages/HomePage';
import PatientAnalysisPage from './pages/PatientAnalysisPage';
import DatasetPage from './pages/DatasetPage';
import DbscanDashboardPage from './pages/DbscanDashboardPage';
import AnomaliesPage from './pages/AnomaliesPage';

import { initialPatientData } from './data/kagglePatientsDataset';
import { DEFAULT_DBSCAN_PARAMS } from './data/defaultParameters';
import { preprocessDataset } from './ml/preprocessor';
import { runDBSCAN } from './ml/dbscanEngine';

export default function App() {
  const [activePage, setActivePage] = useState('home');
  const [rawRecords, setRawRecords] = useState(initialPatientData);

  // Hyperparameters for DBSCAN
  const [eps, setEps] = useState(DEFAULT_DBSCAN_PARAMS.eps);
  const [minPts, setMinPts] = useState(DEFAULT_DBSCAN_PARAMS.minPts);
  const [isProcessing, setIsProcessing] = useState(false);

  // 1. Preprocess raw dataset
  const preprocessed = useMemo(() => {
    return preprocessDataset(rawRecords);
  }, [rawRecords]);

  // 2. Run DBSCAN clustering when preprocessed data or params change
  const dbscanResult = useMemo(() => {
    return runDBSCAN(
      preprocessed.cleanedRecords,
      preprocessed.featureMatrix,
      eps,
      minPts
    );
  }, [preprocessed, eps, minPts]);

  // Reset hyperparameters
  const handleResetParams = useCallback(() => {
    setIsProcessing(true);
    setEps(DEFAULT_DBSCAN_PARAMS.eps);
    setMinPts(DEFAULT_DBSCAN_PARAMS.minPts);
    setTimeout(() => setIsProcessing(false), 200);
  }, []);

  // Reset dataset to default
  const handleResetDataset = useCallback(() => {
    setIsProcessing(true);
    setRawRecords(initialPatientData);
    setTimeout(() => setIsProcessing(false), 200);
  }, []);

  // Upload custom CSV
  const handleUploadCSV = useCallback((newRecords) => {
    setIsProcessing(true);
    setRawRecords(newRecords);
    setTimeout(() => setIsProcessing(false), 200);
  }, []);

  // Manual Trigger for Preprocessing & DBSCAN
  const handlePreprocessAndRun = useCallback((goToDashboard = false) => {
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      if (goToDashboard) {
        setActivePage('dbscan-analysis');
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
    }, 300);
  }, []);

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900 selection:bg-blue-100 selection:text-blue-900">
      
      {/* Top Sticky Medical Safety Disclaimer */}
      <DisclaimerBanner />

      {/* Main Modern Responsive Navigation Bar */}
      <Navbar 
        activePage={activePage} 
        setActivePage={setActivePage} 
        anomalyCount={dbscanResult.metrics.numAnomalies} 
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 pt-6 sm:pt-8">
        {activePage === 'home' && (
          <HomePage 
            setActivePage={setActivePage} 
            metrics={dbscanResult.metrics} 
          />
        )}

        {activePage === 'patient-analysis' && (
          <PatientAnalysisPage 
            clusteredRecords={dbscanResult.clusteredRecords}
            scalerStats={preprocessed.scalerStats}
            eps={eps}
            setActivePage={setActivePage}
          />
        )}

        {activePage === 'dataset' && (
          <DatasetPage 
            rawRecords={rawRecords}
            onResetDataset={handleResetDataset}
            onUploadCSV={handleUploadCSV}
            onPreprocessAndRun={handlePreprocessAndRun}
            isProcessing={isProcessing}
            setActivePage={setActivePage}
          />
        )}

        {activePage === 'dbscan-analysis' && (
          <DbscanDashboardPage 
            clusteredRecords={dbscanResult.clusteredRecords}
            metrics={dbscanResult.metrics}
            clustersSummary={dbscanResult.clustersSummary}
            eps={eps}
            setEps={setEps}
            minPts={minPts}
            setMinPts={setMinPts}
            onResetParams={handleResetParams}
            isRecalculating={isProcessing}
            setActivePage={setActivePage}
          />
        )}

        {activePage === 'anomalies' && (
          <AnomaliesPage 
            clusteredRecords={dbscanResult.clusteredRecords}
            clustersSummary={dbscanResult.clustersSummary}
            setActivePage={setActivePage}
          />
        )}
      </main>

      {/* Modern Academic & Clinical Footer */}
      <Footer setActivePage={setActivePage} />

    </div>
  );
}
