import React from 'react';
import { Sliders, RefreshCw, HelpCircle, Sparkles } from 'lucide-react';

export default function ParameterControls({
  eps,
  setEps,
  minPts,
  setMinPts,
  onReset,
  isRecalculating
}) {
  const presets = [
    { label: "Standard / Balanced", eps: 1.30, minPts: 4 },
    { label: "High Sensitivity (More Outliers)", eps: 1.05, minPts: 5 },
    { label: "Relaxed Neighborhood", eps: 1.60, minPts: 3 }
  ];

  return (
    <div className="bg-white rounded-xl p-5 shadow-xs border border-slate-200">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 mb-4 border-b border-slate-100">
        <div className="flex items-center gap-2.5">
          <div className="p-2 bg-blue-50 text-blue-600 rounded-lg">
            <Sliders className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-slate-800">DBSCAN Hyperparameter Tuning</h4>
            <p className="text-xs text-slate-500">Live calibration of spatial density clustering criteria</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onReset}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-600 hover:text-blue-600 hover:bg-slate-100 rounded-lg transition-colors border border-slate-200"
            title="Reset to default hyperparameters"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isRecalculating ? 'animate-spin' : ''}`} />
            <span>Reset Defaults</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* Epsilon Slider */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs">
            <label htmlFor="epsilon-slider" className="font-semibold text-slate-700 flex items-center gap-1.5">
              <span>Epsilon (&epsilon;) Radius</span>
              <span className="text-slate-400 group relative cursor-help">
                <HelpCircle className="w-3.5 h-3.5" />
              </span>
            </label>
            <span className="px-2.5 py-0.5 bg-blue-50 text-blue-700 font-mono font-bold rounded-md border border-blue-200 text-xs">
              {eps.toFixed(2)}
            </span>
          </div>

          <input
            id="epsilon-slider"
            type="range"
            min="0.70"
            max="2.50"
            step="0.05"
            value={eps}
            onChange={(e) => setEps(parseFloat(e.target.value))}
            className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
          />

          <div className="flex justify-between text-[11px] text-slate-400">
            <span>0.70 (Strict density)</span>
            <span>1.60</span>
            <span>2.50 (Permissive)</span>
          </div>
          <p className="text-[11px] text-slate-500 leading-tight">
            Maximum Euclidean distance between two patient feature vectors for one to be considered reachable from another.
          </p>
        </div>

        {/* MinPts Slider */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs">
            <label htmlFor="minpts-slider" className="font-semibold text-slate-700 flex items-center gap-1.5">
              <span>MinPts (Minimum Samples)</span>
              <span className="text-slate-400 cursor-help">
                <HelpCircle className="w-3.5 h-3.5" />
              </span>
            </label>
            <span className="px-2.5 py-0.5 bg-purple-50 text-purple-700 font-mono font-bold rounded-md border border-purple-200 text-xs">
              {minPts} pts
            </span>
          </div>

          <input
            id="minpts-slider"
            type="range"
            min="2"
            max="10"
            step="1"
            value={minPts}
            onChange={(e) => setMinPts(parseInt(e.target.value, 10))}
            className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-purple-600"
          />

          <div className="flex justify-between text-[11px] text-slate-400">
            <span>2 (Fine clusters)</span>
            <span>5</span>
            <span>10 (Requires high density)</span>
          </div>
          <p className="text-[11px] text-slate-500 leading-tight">
            Minimum number of patient vectors required within radius &epsilon; to establish a dense core cluster node.
          </p>
        </div>

      </div>

      {/* Quick Presets */}
      <div className="mt-4 pt-3 border-t border-slate-100 flex flex-wrap items-center gap-2">
        <span className="text-xs font-medium text-slate-500 flex items-center gap-1 mr-1">
          <Sparkles className="w-3 h-3 text-amber-500" />
          Presets:
        </span>
        {presets.map((p, i) => (
          <button
            key={i}
            onClick={() => {
              setEps(p.eps);
              setMinPts(p.minPts);
            }}
            className={`text-xs px-2.5 py-1 rounded-md transition-colors ${
              eps === p.eps && minPts === p.minPts
                ? 'bg-blue-600 text-white font-semibold'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            {p.label}
          </button>
        ))}
      </div>
    </div>
  );
}
