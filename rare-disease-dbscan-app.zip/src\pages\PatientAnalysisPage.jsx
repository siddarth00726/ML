import React, { useState } from 'react';
import { 
  UserCheck, 
  AlertTriangle, 
  CheckCircle, 
  Info, 
  Sparkles, 
  RotateCcw, 
  Activity, 
  Heart, 
  FileText, 
  AlertCircle,
  ShieldCheck,
  ChevronRight,
  ClipboardList
} from 'lucide-react';
import { predictPatientAnomaly } from '../ml/patientPredictor';

export default function PatientAnalysisPage({ clusteredRecords, scalerStats, eps, setActivePage }) {
  // Form State
  const [formData, setFormData] = useState({
    id: "PT-NEW-2045",
    age: "35",
    gender: "Female",
    fever: "No",
    cough: "No",
    fatigue: "Yes",
    difficultyBreathing: "Yes",
    bloodPressure: "High",
    cholesterol: "High",
    testResult: "Positive",
    medicalCondition: "Atypical Dyspnea with Rapid Onset Hypertension",
    medicalHistory: "Patient exhibits unexplained peripheral neuropathy, early exertional dyspnea, and sudden elevation in systolic BP without prior cardiovascular history."
  });

  const [analyzedResult, setAnalyzedResult] = useState(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  // Quick preset loaders for convenient demonstration
  const loadPreset = (type) => {
    if (type === 'common-cold') {
      setFormData({
        id: "PT-CASE-COLD",
        age: "27",
        gender: "Female",
        fever: "Yes",
        cough: "Yes",
        fatigue: "Yes",
        difficultyBreathing: "No",
        bloodPressure: "Normal",
        cholesterol: "Normal",
        testResult: "Positive",
        medicalCondition: "Upper Respiratory Tract Syndrome",
        medicalHistory: "Acute onset 3 days ago. No prior chronic illnesses, non-smoker."
      });
      setAnalyzedResult(null);
    } else if (type === 'hypertension') {
      setFormData({
        id: "PT-CASE-METABOLIC",
        age: "63",
        gender: "Male",
        fever: "No",
        cough: "No",
        fatigue: "Yes",
        difficultyBreathing: "No",
        bloodPressure: "High",
        cholesterol: "High",
        testResult: "Positive",
        medicalCondition: "Age-associated Hypertension",
        medicalHistory: "Known history of elevated fasting glucose and sedentary lifestyle."
      });
      setAnalyzedResult(null);
    } else if (type === 'atypical') {
      setFormData({
        id: "PT-CASE-ATYPICAL",
        age: "19",
        gender: "Male",
        fever: "No",
        cough: "No",
        fatigue: "Yes",
        difficultyBreathing: "Yes",
        bloodPressure: "High",
        cholesterol: "High",
        testResult: "Positive",
        medicalCondition: "Unexplained Multi-Organ Juvenile Presentation",
        medicalHistory: "Severe burning acroparesthesia in hands/feet, early cardiac hypertrophy at age 19, hypohidrosis, severe biomarker incongruity."
      });
      setAnalyzedResult(null);
    } else if (type === 'asthma') {
      setFormData({
        id: "PT-CASE-ASTHMA",
        age: "34",
        gender: "Female",
        fever: "No",
        cough: "Yes",
        fatigue: "Yes",
        difficultyBreathing: "Yes",
        bloodPressure: "Normal",
        cholesterol: "Normal",
        testResult: "Positive",
        medicalCondition: "Suspected Bronchospasm",
        medicalHistory: "Seasonal allergy history; complaints of nocturnal wheeze and tight chest."
      });
      setAnalyzedResult(null);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleAnalyze = (e) => {
    e.preventDefault();
    setIsAnalyzing(true);

    setTimeout(() => {
      const result = predictPatientAnomaly(formData, clusteredRecords, scalerStats, eps);
      setAnalyzedResult(result);
      setIsAnalyzing(false);
    }, 400);
  };

  const resetForm = () => {
    setFormData({
      id: `PT-${Math.floor(1000 + Math.random() * 9000)}`,
      age: "",
      gender: "Male",
      fever: "No",
      cough: "No",
      fatigue: "No",
      difficultyBreathing: "No",
      bloodPressure: "Normal",
      cholesterol: "Normal",
      testResult: "Negative",
      medicalCondition: "",
      medicalHistory: ""
    });
    setAnalyzedResult(null);
  };

  return (
    <div className="space-y-8 pb-12">
      
      {/* Page Header */}
      <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 text-blue-700 border border-blue-200 text-xs font-semibold mb-3">
            <UserCheck className="w-3.5 h-3.5" />
            <span>Clinical Anomaly Inference</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900">
            Patient Analysis &amp; Outlier Evaluation
          </h1>
          <p className="text-sm text-slate-500 mt-1 max-w-2xl">
            Input a patient’s demographic, symptom profile, and diagnostic vitals. The fitted DBSCAN engine maps the vector into high-dimensional space to compute spatial density reachability.
          </p>
        </div>

        {/* Demo Quick Presets */}
        <div className="bg-slate-50 p-3 rounded-xl border border-slate-200/80 shrink-0">
          <div className="text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-2 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-amber-500" />
            <span>Load Quick Test Presets</span>
          </div>
          <div className="grid grid-cols-2 gap-1.5">
            <button
              onClick={() => loadPreset('common-cold')}
              className="text-xs px-2.5 py-1.5 bg-white hover:bg-blue-50 hover:text-blue-700 text-slate-700 rounded-lg border border-slate-200 transition-colors text-left"
            >
              Common Cold (Cluster 0)
            </button>
            <button
              onClick={() => loadPreset('hypertension')}
              className="text-xs px-2.5 py-1.5 bg-white hover:bg-purple-50 hover:text-purple-700 text-slate-700 rounded-lg border border-slate-200 transition-colors text-left"
            >
              Hypertension (Cluster 1)
            </button>
            <button
              onClick={() => loadPreset('asthma')}
              className="text-xs px-2.5 py-1.5 bg-white hover:bg-cyan-50 hover:text-cyan-700 text-slate-700 rounded-lg border border-slate-200 transition-colors text-left"
            >
              Asthma (Cluster 2)
            </button>
            <button
              onClick={() => loadPreset('atypical')}
              className="text-xs px-2.5 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-800 rounded-lg border border-rose-200 font-semibold transition-colors text-left flex items-center justify-between"
            >
              <span>Atypical Rare Case</span>
              <AlertTriangle className="w-3 h-3 text-rose-600" />
            </button>
          </div>
        </div>
      </div>

      {/* Main Form & Results Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Patient Intake Form (7 Cols on LG) */}
        <div className="lg:col-span-7 bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between pb-4 mb-6 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <ClipboardList className="w-5 h-5 text-blue-600" />
              <h2 className="text-base font-bold text-slate-800">Patient Clinical Intake Profile</h2>
            </div>
            <button
              type="button"
              onClick={resetForm}
              className="text-xs text-slate-500 hover:text-slate-800 flex items-center gap-1 transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Clear Form</span>
            </button>
          </div>

          <form onSubmit={handleAnalyze} className="space-y-6">
            
            {/* Row 1: ID, Age, Gender */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Patient ID *
                </label>
                <input
                  type="text"
                  name="id"
                  required
                  value={formData.id}
                  onChange={handleInputChange}
                  className="w-full px-3.5 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-500 font-mono"
                  placeholder="e.g. PT-2045"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Age (Years) *
                </label>
                <input
                  type="number"
                  name="age"
                  required
                  min="1"
                  max="120"
                  value={formData.age}
                  onChange={handleInputChange}
                  className="w-full px-3.5 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-500"
                  placeholder="e.g. 35"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Gender *
                </label>
                <select
                  name="gender"
                  value={formData.gender}
                  onChange={handleInputChange}
                  className="w-full px-3.5 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-500"
                >
                  <option value="Female">Female</option>
                  <option value="Male">Male</option>
                  <option value="Other">Other</option>
                </select>
              </div>
            </div>

            {/* Row 2: Symptoms Checklist (Fever, Cough, Fatigue, Difficulty Breathing) */}
            <div className="bg-slate-50/80 p-4 rounded-xl border border-slate-200/80 space-y-3">
              <span className="text-xs font-bold text-slate-700 uppercase tracking-wide block">
                Primary Symptoms Assessment (Binary ML Indicators)
              </span>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                
                {/* Fever */}
                <div className="bg-white p-3 rounded-lg border border-slate-200 shadow-2xs">
                  <label className="block text-xs font-medium text-slate-600 mb-1">Fever</label>
                  <select
                    name="fever"
                    value={formData.fever}
                    onChange={handleInputChange}
                    className="w-full text-xs font-semibold p-1.5 border border-slate-200 rounded-md focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="No">No</option>
                    <option value="Yes">Yes</option>
                  </select>
                </div>

                {/* Cough */}
                <div className="bg-white p-3 rounded-lg border border-slate-200 shadow-2xs">
                  <label className="block text-xs font-medium text-slate-600 mb-1">Cough</label>
                  <select
                    name="cough"
                    value={formData.cough}
                    onChange={handleInputChange}
                    className="w-full text-xs font-semibold p-1.5 border border-slate-200 rounded-md focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="No">No</option>
                    <option value="Yes">Yes</option>
                  </select>
                </div>

                {/* Fatigue */}
                <div className="bg-white p-3 rounded-lg border border-slate-200 shadow-2xs">
                  <label className="block text-xs font-medium text-slate-600 mb-1">Fatigue</label>
                  <select
                    name="fatigue"
                    value={formData.fatigue}
                    onChange={handleInputChange}
                    className="w-full text-xs font-semibold p-1.5 border border-slate-200 rounded-md focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="No">No</option>
                    <option value="Yes">Yes</option>
                  </select>
                </div>

                {/* Difficulty Breathing */}
                <div className="bg-white p-3 rounded-lg border border-slate-200 shadow-2xs">
                  <label className="block text-xs font-medium text-slate-600 mb-1">Dyspnea / Breathing</label>
                  <select
                    name="difficultyBreathing"
                    value={formData.difficultyBreathing}
                    onChange={handleInputChange}
                    className="w-full text-xs font-semibold p-1.5 border border-slate-200 rounded-md focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="No">No</option>
                    <option value="Yes">Yes</option>
                  </select>
                </div>

              </div>
            </div>

            {/* Row 3: Vitals & Test Results */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Blood Pressure *
                </label>
                <select
                  name="bloodPressure"
                  value={formData.bloodPressure}
                  onChange={handleInputChange}
                  className="w-full px-3.5 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-500"
                >
                  <option value="Normal">Normal</option>
                  <option value="Elevated">Elevated</option>
                  <option value="High">High</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Cholesterol Level *
                </label>
                <select
                  name="cholesterol"
                  value={formData.cholesterol}
                  onChange={handleInputChange}
                  className="w-full px-3.5 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-500"
                >
                  <option value="Normal">Normal</option>
                  <option value="High">High</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Test Results *
                </label>
                <select
                  name="testResult"
                  value={formData.testResult}
                  onChange={handleInputChange}
                  className="w-full px-3.5 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-500"
                >
                  <option value="Negative">Negative (Normal)</option>
                  <option value="Positive">Positive (Abnormal findings)</option>
                </select>
              </div>
            </div>

            {/* Row 4: Medical Conditions & Clinical Notes */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                Current Medical Condition / Referral Diagnosis
              </label>
              <input
                type="text"
                name="medicalCondition"
                value={formData.medicalCondition}
                onChange={handleInputChange}
                className="w-full px-3.5 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-500"
                placeholder="e.g. Unspecified acute respiratory symptoms"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                Medical History &amp; Detailed Clinical Notes
              </label>
              <textarea
                name="medicalHistory"
                rows="3"
                value={formData.medicalHistory}
                onChange={handleInputChange}
                className="w-full px-3.5 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-500"
                placeholder="Enter previous surgeries, chronic illnesses, familial conditions, or atypical test results..."
              />
            </div>

            {/* Prominent Submit Button */}
            <div>
              <button
                type="submit"
                disabled={isAnalyzing}
                className="w-full py-4 px-6 rounded-xl bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-bold text-base shadow-lg shadow-blue-500/25 flex items-center justify-center gap-3 transition-all duration-200 transform hover:-translate-y-0.5 disabled:opacity-60"
              >
                {isAnalyzing ? (
                  <>
                    <Activity className="w-5 h-5 animate-spin" />
                    <span>Mapping Euclidean Space &amp; Computing Density...</span>
                  </>
                ) : (
                  <>
                    <UserCheck className="w-5 h-5" />
                    <span>Analyze Patient</span>
                  </>
                )}
              </button>
            </div>

          </form>
        </div>

        {/* Inference & Analysis Result Section (5 Cols on LG) */}
        <div className="lg:col-span-5 space-y-6">
          
          {analyzedResult ? (
            <div className="bg-white rounded-2xl p-6 sm:p-7 border border-slate-200 shadow-md animate-in fade-in zoom-in-95 duration-300">
              
              {/* Card Header Status */}
              <div className="flex items-center justify-between pb-4 border-b border-slate-100">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono font-bold text-slate-500 bg-slate-100 px-2.5 py-1 rounded-md">
                    {analyzedResult.patientId}
                  </span>
                  <span className="text-xs text-slate-400">Analysis Result</span>
                </div>

                <span className={`px-3 py-1 rounded-full text-xs font-bold border ${analyzedResult.badgeColor}`}>
                  {analyzedResult.riskLevel}
                </span>
              </div>

              {/* Status Alert Banner */}
              <div className={`mt-5 p-4 rounded-xl border ${
                analyzedResult.isAnomaly 
                  ? 'bg-rose-50 border-rose-200 text-rose-900' 
                  : 'bg-emerald-50 border-emerald-200 text-emerald-900'
              }`}>
                <div className="flex items-start gap-3">
                  {analyzedResult.isAnomaly ? (
                    <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
                  ) : (
                    <CheckCircle className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                  )}
                  <div>
                    <h3 className="font-bold text-sm">
                      {analyzedResult.isAnomaly 
                        ? "Potential unusual case detected — further medical examination recommended." 
                        : "Clinical presentation conforms to established population clusters."}
                    </h3>
                    <p className="text-xs mt-1 opacity-90">
                      {analyzedResult.alertIndicator}
                    </p>
                  </div>
                </div>
              </div>

              {/* Metrics Grid */}
              <div className="grid grid-cols-2 gap-3 my-5">
                <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200">
                  <div className="text-[11px] font-semibold text-slate-500 uppercase tracking-wide">
                    Assigned Cluster
                  </div>
                  <div className="text-lg font-black text-slate-800 mt-1">
                    {analyzedResult.clusterId === -1 ? (
                      <span className="text-rose-600 font-mono">Cluster -1 (Noise)</span>
                    ) : (
                      <span className="text-blue-600 font-mono">Cluster #{analyzedResult.clusterId}</span>
                    )}
                  </div>
                  <div className="text-[10px] text-slate-400 mt-0.5">
                    {analyzedResult.clusterId === -1 ? "Spatial density outlier" : "Density-reachable cohort"}
                  </div>
                </div>

                <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200">
                  <div className="text-[11px] font-semibold text-slate-500 uppercase tracking-wide">
                    Anomaly Score
                  </div>
                  <div className="text-lg font-black text-slate-800 mt-1 font-mono">
                    {analyzedResult.anomalyScore}
                  </div>
                  <div className="text-[10px] text-slate-400 mt-0.5">
                    Dist: {analyzedResult.coreDistance} (&epsilon; threshold: {eps.toFixed(2)})
                  </div>
                </div>
              </div>

              {/* Patient Summary Details */}
              <div className="space-y-2.5 py-3 border-t border-b border-slate-100 text-xs">
                <div className="text-xs font-bold text-slate-700 uppercase tracking-wide">
                  Patient Summary
                </div>
                <div className="flex justify-between py-1 border-b border-slate-50">
                  <span className="text-slate-500">Age &amp; Gender:</span>
                  <span className="font-semibold text-slate-800">{formData.age} yrs, {formData.gender}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-50">
                  <span className="text-slate-500">Reported Symptoms:</span>
                  <span className="font-semibold text-slate-800">
                    {[
                      formData.fever === 'Yes' && 'Fever',
                      formData.cough === 'Yes' && 'Cough',
                      formData.fatigue === 'Yes' && 'Fatigue',
                      formData.difficultyBreathing === 'Yes' && 'Dyspnea'
                    ].filter(Boolean).join(', ') || 'None reported'}
                  </span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-50">
                  <span className="text-slate-500">Blood Pressure / Lipids:</span>
                  <span className="font-semibold text-slate-800">{formData.bloodPressure} BP / {formData.cholesterol} Chol</span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-slate-500">Closest Reference Cohort:</span>
                  <span className="font-semibold text-blue-700 truncate max-w-[200px]">{analyzedResult.nearestCohortMatch}</span>
                </div>
              </div>

              {/* Recommendation for Medical Examination */}
              <div className="mt-5 space-y-2">
                <div className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                  <FileText className="w-4 h-4 text-indigo-600" />
                  <span>Clinical Recommendation &amp; Next Steps</span>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed bg-slate-50 p-3.5 rounded-xl border border-slate-200">
                  {analyzedResult.recommendation}
                </p>
              </div>

              {/* Strict Disclaimer in result card */}
              <div className="mt-5 pt-4 border-t border-slate-100 flex items-start gap-2 text-[11px] text-slate-400">
                <ShieldCheck className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
                <p>
                  Important: Anomaly detection identifies non-conforming feature distributions. It does not certify or diagnose any specific rare disease. All decisions must be made by licensed clinicians.
                </p>
              </div>

            </div>
          ) : (
            <div className="bg-slate-50 rounded-2xl p-8 border border-dashed border-slate-300 text-center flex flex-col items-center justify-center min-h-[400px]">
              <div className="w-14 h-14 rounded-2xl bg-blue-100/60 text-blue-600 flex items-center justify-center mb-4">
                <UserCheck className="w-7 h-7" />
              </div>
              <h3 className="text-base font-bold text-slate-700">Awaiting Patient Assessment</h3>
              <p className="text-xs text-slate-500 max-w-xs mt-1.5 leading-relaxed">
                Fill out the clinical intake form on the left or select a quick test preset above, then click <strong>“Analyze Patient”</strong>.
              </p>
              <div className="mt-6 flex items-center gap-2 text-xs text-blue-600 font-medium bg-blue-50 px-3 py-1.5 rounded-lg border border-blue-200">
                <Info className="w-4 h-4" />
                <span>Current &epsilon; = {eps.toFixed(2)} | MinPts = 4</span>
              </div>
            </div>
          )}

        </div>

      </div>

    </div>
  );
}
