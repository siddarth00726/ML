"""
Rare-Disease Case Identification Using DBSCAN-Based Anomaly Detection
Academic Guidance: Dr. Dyuti Banerjee, Assistant Professor AI & DS

This module implements the unsupervised machine-learning anomaly detection
pipeline using DBSCAN on patient profile data.

Safety Notice:
This system is an anomaly-detection decision-support demonstration and does not
replace professional medical diagnosis. An anomaly indicates statistical isolation
in biomarker space, NOT a certified rare disease diagnosis.
"""

import os
import sys
import numpy as np
import pandas as pd
from sklearn.cluster import DBSCAN
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA

class RareDiseaseDBSCANDetector:
    def __init__(self, eps=1.30, min_samples=4):
        self.eps = eps
        self.min_samples = min_samples
        self.scaler = StandardScaler()
        self.model = None
        self.pca = PCA(n_components=2)
        self.feature_columns = [
            'Age', 'Fever', 'Cough', 'Fatigue', 
            'Difficulty Breathing', 'Blood Pressure', 
            'Cholesterol Level', 'Outcome Variable'
        ]

    def preprocess(self, df: pd.DataFrame) -> np.ndarray:
        """
        Executes the 7-step clinical preprocessing pipeline:
        1. Deduplicate records
        2. Impute missing values
        3. Correct datatypes
        4. Encode categorical values
        5. Check invalid values
        6. Select relevant features
        7. Standardize numerical features
        """
        df_clean = df.copy()

        # Step 1: Remove duplicate records
        df_clean = df_clean.drop_duplicates()

        # Step 2 & 3: Handle missing values and correct data types
        df_clean['Age'] = pd.to_numeric(df_clean['Age'], errors='coerce')
        median_age = df_clean['Age'].median() if not df_clean['Age'].empty else 40
        df_clean['Age'] = df_clean['Age'].fillna(median_age)

        # Step 4: Encode categorical values
        binary_map = {'yes': 1.0, 'no': 0.0, 'positive': 1.0, 'negative': 0.0}
        
        for col in ['Fever', 'Cough', 'Fatigue', 'Difficulty Breathing']:
            if col in df_clean.columns:
                df_clean[col] = df_clean[col].astype(str).str.lower().map(binary_map).fillna(0.0)
            else:
                df_clean[col] = 0.0

        # Blood Pressure encoding (Normal=0, Elevated=0.5, High=1.0)
        def encode_bp(val):
            val_str = str(val).lower()
            if 'high' in val_str:
                return 1.0
            elif 'elev' in val_str:
                return 0.5
            return 0.0

        if 'Blood Pressure' in df_clean.columns:
            df_clean['Blood Pressure'] = df_clean['Blood Pressure'].apply(encode_bp)
        else:
            df_clean['Blood Pressure'] = 0.0

        # Cholesterol Level encoding (High=1.0, Normal=0.0)
        if 'Cholesterol Level' in df_clean.columns:
            df_clean['Cholesterol Level'] = df_clean['Cholesterol Level'].astype(str).str.lower().apply(
                lambda x: 1.0 if 'high' in x else 0.0
            )
        else:
            df_clean['Cholesterol Level'] = 0.0

        # Outcome Variable / Test Result
        if 'Outcome Variable' in df_clean.columns:
            df_clean['Outcome Variable'] = df_clean['Outcome Variable'].astype(str).str.lower().map(binary_map).fillna(0.0)
        elif 'Test Result' in df_clean.columns:
            df_clean['Outcome Variable'] = df_clean['Test Result'].astype(str).str.lower().map(binary_map).fillna(0.0)
        else:
            df_clean['Outcome Variable'] = 0.0

        # Step 5: Check invalid values
        df_clean = df_clean[(df_clean['Age'] > 0) & (df_clean['Age'] <= 120)]

        # Step 6: Select relevant features
        feature_matrix = df_clean[self.feature_columns].values

        # Step 7: Standardize numerical features (StandardScaler)
        scaled_features = self.scaler.fit_transform(feature_matrix)

        return df_clean, scaled_features

    def fit_predict(self, df: pd.DataFrame):
        """Fits DBSCAN model and returns clustered dataframe with anomaly flags."""
        df_clean, scaled_features = self.preprocess(df)

        self.model = DBSCAN(eps=self.eps, min_samples=self.min_samples, metric='euclidean')
        cluster_labels = self.model.fit_predict(scaled_features)

        # 2D PCA projection for visualization
        pca_coords = self.pca.fit_transform(scaled_features)

        df_clean['Cluster'] = cluster_labels
        df_clean['Is_Anomaly'] = cluster_labels == -1
        df_clean['Status'] = np.where(cluster_labels == -1, 'Anomaly Detected', 'Normal Pattern')
        df_clean['PCA_1'] = pca_coords[:, 0]
        df_clean['PCA_2'] = pca_coords[:, 1]

        # Compute Anomaly Score (distance to nearest core point)
        core_samples_indices = self.model.core_sample_indices_
        if len(core_samples_indices) > 0:
            core_points = scaled_features[core_samples_indices]
            from scipy.spatial.distance import cdist
            distances_to_core = cdist(scaled_features, core_points, metric='euclidean')
            df_clean['Anomaly_Score'] = np.min(distances_to_core, axis=1).round(3)
        else:
            df_clean['Anomaly_Score'] = 1.0

        return df_clean

    def evaluate_new_patient(self, patient_dict: dict):
        """Inference function for a single incoming patient record."""
        df_single = pd.DataFrame([patient_dict])
        _, scaled_input = self.preprocess(df_single)
        
        # Determine distance to known core points
        if self.model and len(self.model.core_sample_indices_) > 0:
            core_points = self.scaler.transform(self.model.components_)
            from scipy.spatial.distance import cdist
            dist = cdist(scaled_input, core_points, metric='euclidean').min()
            is_anomaly = dist > self.eps
        else:
            dist = 1.5
            is_anomaly = True

        return {
            "patient_id": patient_dict.get("id", "PT-INPUT"),
            "cluster_id": -1 if is_anomaly else 0,
            "anomaly_score": round(float(dist), 3),
            "is_anomaly": bool(is_anomaly),
            "alert_status": "Potential unusual case detected — further medical examination recommended." if is_anomaly else "Normal Pattern",
            "recommendation": "Specialist referral advised for detailed biomarker profiling." if is_anomaly else "Standard clinical observation."
        }

if __name__ == "__main__":
    print("=" * 70)
    print("Rare-Disease Case Identification Using DBSCAN-Based Anomaly Detection")
    print("Academic Guidance: Dr. Dyuti Banerjee, Assistant Professor AI & DS")
    print("=" * 70)

    # Generate synthetic benchmark matching Kaggle dataset
    np.random.seed(42)
    n_samples = 150
    data = {
        'Age': np.random.randint(18, 80, size=n_samples),
        'Gender': np.random.choice(['Male', 'Female'], size=n_samples),
        'Fever': np.random.choice(['Yes', 'No'], p=[0.4, 0.6], size=n_samples),
        'Cough': np.random.choice(['Yes', 'No'], p=[0.5, 0.5], size=n_samples),
        'Fatigue': np.random.choice(['Yes', 'No'], p=[0.6, 0.4], size=n_samples),
        'Difficulty Breathing': np.random.choice(['Yes', 'No'], p=[0.25, 0.75], size=n_samples),
        'Blood Pressure': np.random.choice(['Normal', 'Elevated', 'High'], p=[0.5, 0.2, 0.3], size=n_samples),
        'Cholesterol Level': np.random.choice(['Normal', 'High'], p=[0.6, 0.4], size=n_samples),
        'Outcome Variable': np.random.choice(['Positive', 'Negative'], p=[0.55, 0.45], size=n_samples)
    }
    df_sample = pd.DataFrame(data)

    detector = RareDiseaseDBSCANDetector(eps=1.30, min_samples=4)
    result_df = detector.fit_predict(df_sample)

    n_anomalies = (result_df['Cluster'] == -1).sum()
    n_clusters = len(set(result_df['Cluster'])) - (1 if -1 in result_df['Cluster'].values else 0)

    print(f"\n[Execution Summary]")
    print(f"Total Patient Records : {len(result_df)}")
    print(f"Clusters Identified    : {n_clusters}")
    print(f"Anomalies (Noise -1)   : {n_anomalies} ({(n_anomalies / len(result_df) * 100):.1f}%)")
    print(f"Normal Cases           : {len(result_df) - n_anomalies}")
    print("\nSample Anomalies Detected (Potential Unusual Cases):")
    print(result_df[result_df['Is_Anomaly']][['Age', 'Fever', 'Cough', 'Blood Pressure', 'Anomaly_Score', 'Status']].head())
