import React, { useState } from 'react';
import { 
  BookOpen, 
  GraduationCap, 
  Cpu, 
  HardDrive, 
  Terminal, 
  ExternalLink, 
  ShieldAlert, 
  Layers, 
  Network, 
  Code2, 
  CheckCircle,
  FileSpreadsheet,
  Monitor
} from 'lucide-react';

export default function AboutPage() {
  const [activeTab, setActiveTab] = useState('overview');

  const pythonSnippet = `# Rare-Disease Anomaly Detection Pipeline
# Supervised by: Dr. Dyuti Banerjee, Assistant Professor AI & DS
import pandas as pd
import numpy as np
from sklearn.cluster import DBSCAN
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA

def run_dbscan_rare_disease_pipeline(csv_path="disease_patient_dataset.csv", eps=1.30, min_samples=4):
    # 1. Load Dataset
    df = pd.read_csv(csv_path)
    
    # 2. Preprocessing & Encoding
    binary_map = {'Yes': 1, 'No': 0, 'Positive': 1, 'Negative': 0}
    bp_map = {'Normal': 0, 'Elevated': 0.5, 'High': 1.0}
    
    features_df = pd.DataFrame({
        'Age': df['Age'].fillna(df['Age'].median()),
        'Fever': df['Fever'].map(binary_map).fillna(0),
        'Cough': df['Cough'].map(binary_map).fillna(0),
        'Fatigue': df['Fatigue'].map(binary_map).fillna(0),
        'Dyspnea': df['Difficulty Breathing'].map(binary_map).fillna(0),
        'BP': df['Blood Pressure'].map(bp_map).fillna(0),
        'Cholesterol': df['Cholesterol Level'].map(lambda x: 1.0 if str(x).lower() == 'high' else 0.0),
        'Outcome': df['Outcome Variable'].map(binary_map).fillna(0)
    })
    
    # 3. Standardization (Z-Score)
    scaler = StandardScaler()
    scaled_matrix = scaler.fit_transform(features_df)
    
    # 4. Fit DBSCAN
    dbscan = DBSCAN(eps=eps, min_samples=min_samples, metric='euclidean')
    labels = dbscan.fit_predict(scaled_matrix)
    
    df['Cluster'] = labels
    df['Anomaly_Status'] = np.where(labels == -1, 'Anomaly Detected', 'Normal Pattern')
    
    # 5. Summary Metrics
    n_anomalies = int(np.sum(labels == -1))
    n_clusters = len(set(labels)) - (1 if -1 in labels else 0)
    print(f"Total Patients: {len(df)} | Clusters: {n_clusters} | Anomalies: {n_anomalies}")
    
    return df, dbscan, scaler

if __name__ == "__main__":
    df_result, model, scaler = run_dbscan_rare_disease_pipeline()
`;

  return (
    <div className="space-y-8 pb-12">
      
      {/* Page Header */}
      <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 text-blue-700 border border-blue-200 text-xs font-semibold mb-2">
            <BookOpen className="w-3.5 h-3.5" />
            <span>Academic Project Documentation</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900">
            About the Project &amp; Mathematical Foundations
          </h1>
          <p className="text-sm text-slate-500 mt-1 max-w-2xl">
            Theoretical principles of DBSCAN-based healthcare anomaly detection, technical specifications, and academic guidance.
          </p>
        </div>

        {/* Academic Mentorship Card */}
        <div className="p-4 bg-gradient-to-br from-blue-50 to-indigo-50 border border-blue-200 rounded-2xl shrink-0 shadow-xs">
          <div className="flex items-center gap-2 text-xs font-bold text-blue-800 uppercase tracking-wide">
            <GraduationCap className="w-4 h-4 text-blue-600" />
            <span>Project Guidance &amp; Mentorship</span>
          </div>
          <div className="mt-2">
            <div className="text-base font-bold text-slate-900">Dr. Dyuti Banerjee</div>
            <div className="text-xs text-blue-700 font-medium">Assistant Professor, AI &amp; DS</div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-1 overflow-x-auto text-xs font-bold">
        {[
          { id: 'overview', label: 'Project Abstract & Rationale' },
          { id: 'algorithm', label: 'DBSCAN Mathematical Theory' },
          { id: 'requirements', label: 'System Specifications' },
          { id: 'python', label: 'Python ML Backend Code' }
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`px-4 py-2.5 rounded-xl whitespace-nowrap transition-all ${
              activeTab === tab.id
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Tab 1: Overview & Abstract */}
      {activeTab === 'overview' && (
        <div className="space-y-8 animate-in fade-in duration-200">
          
          {/* Abstract Card (Matching Slide 2) */}
          <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-4">
            <span className="text-xs font-bold text-blue-600 uppercase tracking-wider bg-blue-50 px-2.5 py-1 rounded-full border border-blue-200">
              Executive Abstract (Slide 2)
            </span>
            <h2 className="text-xl font-bold text-slate-900">
              Unsupervised Rare-Disease Anomaly Detection
            </h2>
            <div className="space-y-3 text-sm text-slate-600 leading-relaxed">
              <p>
                Rare diseases are notoriously difficult to identify because their symptoms often resemble common diseases, leading to delayed diagnosis and prolonged patient suffering. This project uses <strong>DBSCAN (Density-Based Spatial Clustering of Applications with Noise)</strong>, an unsupervised machine learning technique, to detect unusual patient cases directly from multi-dimensional healthcare observations.
              </p>
              <p>
                The system analyzes patient information such as <strong>age, symptoms, medical history, and test results</strong>. After preprocessing the data, DBSCAN groups patients with similar health patterns into dense clusters and identifies records that do not fit any cluster as anomalies (outliers). These unusual cases can be flagged for further specialized medical examination.
              </p>
              <p>
                The project is implemented using <strong>Python, Pandas, NumPy, Scikit-learn, and Matplotlib</strong> on the backend, with a reactive interactive dashboard on the frontend. The main objective is to assist healthcare professionals in identifying potential rare-disease cases earlier. The system is designed strictly as a <strong>decision-support tool, not a replacement for medical diagnosis</strong>.
              </p>
            </div>
          </div>

          {/* Introduction & Value Proposition (Matching Slide 3) */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-3">
              <span className="text-xs font-bold text-indigo-600 uppercase tracking-wider">
                Clinical Problem (Slide 3)
              </span>
              <h3 className="text-base font-bold text-slate-800">
                The Diagnostic Challenge
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Rare diseases are challenging to diagnose because they occur infrequently and often exhibit symptoms similar to common diseases. Delayed diagnosis may result in ineffective treatment and increased healthcare costs. Machine learning provides advanced techniques for analyzing large healthcare datasets and uncovering subtle, non-linear multi-symptom anomalies.
              </p>
            </div>

            <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-3">
              <span className="text-xs font-bold text-purple-600 uppercase tracking-wider">
                Machine Learning Solution (Slide 3)
              </span>
              <h3 className="text-base font-bold text-slate-800">
                Density-Based Outlier Detection
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                DBSCAN is a density-based clustering algorithm capable of detecting anomalies without requiring labeled training datasets. It groups similar patient records into cohesive clusters while identifying isolated data points as noise/outliers. In our clinical framework, these outliers represent candidate patients with atypical or rare-disease presentations.
              </p>
            </div>
          </div>

          {/* Technologies Used Cards */}
          <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-xs">
            <h3 className="text-base font-bold text-slate-800 mb-4">
              Core Technologies &amp; Libraries
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4">
              {[
                { name: "Python 3.10+", role: "Core ML Runtime", bg: "bg-blue-50 text-blue-700 border-blue-200" },
                { name: "Pandas", role: "Tabular Processing", bg: "bg-indigo-50 text-indigo-700 border-indigo-200" },
                { name: "NumPy", role: "Vector & Matrix Math", bg: "bg-purple-50 text-purple-700 border-purple-200" },
                { name: "Scikit-learn", role: "DBSCAN & Scaler", bg: "bg-orange-50 text-orange-700 border-orange-200" },
                { name: "Matplotlib", role: "Diagnostic Plots", bg: "bg-teal-50 text-teal-700 border-teal-200" }
              ].map((tech, i) => (
                <div key={i} className={`p-3.5 rounded-xl border ${tech.bg}`}>
                  <div className="text-xs font-bold">{tech.name}</div>
                  <div className="text-[11px] opacity-80 mt-0.5">{tech.role}</div>
                </div>
              ))}
            </div>
          </div>

        </div>
      )}

      {/* Tab 2: DBSCAN Mathematical Theory */}
      {activeTab === 'algorithm' && (
        <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-6 animate-in fade-in duration-200">
          <div>
            <span className="text-xs font-bold text-purple-600 uppercase tracking-wider bg-purple-50 px-2.5 py-1 rounded-full border border-purple-200">
              Algorithmic Mechanics
            </span>
            <h2 className="text-xl font-bold text-slate-900 mt-2">
              DBSCAN (Density-Based Spatial Clustering of Applications with Noise)
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              Authored by Ester, Kriegel, Sander, and Xu (1996); widely adopted for arbitrary-shape clustering and robust anomaly isolation.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-5 text-xs">
            
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
              <div className="flex items-center gap-2 font-bold text-blue-700">
                <span className="w-2.5 h-2.5 rounded-full bg-blue-600" />
                <span>1. Core Point</span>
              </div>
              <p className="text-slate-600 leading-relaxed">
                A patient record <code className="bg-white px-1 py-0.5 rounded border border-slate-200 font-mono">p</code> is a <strong>core point</strong> if at least <code className="bg-white px-1 py-0.5 rounded border border-slate-200 font-mono">MinPts</code> patient records reside within distance <code className="bg-white px-1 py-0.5 rounded border border-slate-200 font-mono">&epsilon;</code>:
              </p>
              <div className="p-2 bg-white rounded border font-mono text-center text-slate-800">
                |N<sub>&epsilon;</sub>(p)| &ge; MinPts
              </div>
            </div>

            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
              <div className="flex items-center gap-2 font-bold text-purple-700">
                <span className="w-2.5 h-2.5 rounded-full bg-purple-600" />
                <span>2. Border Point</span>
              </div>
              <p className="text-slate-600 leading-relaxed">
                A patient record is a <strong>border point</strong> if it is within distance <code className="bg-white px-1 py-0.5 rounded border border-slate-200 font-mono">&epsilon;</code> of a core point, but contains fewer than <code className="bg-white px-1 py-0.5 rounded border border-slate-200 font-mono">MinPts</code> points in its own neighborhood.
              </p>
              <div className="p-2 bg-white rounded border font-mono text-center text-slate-800">
                p &isin; N<sub>&epsilon;</sub>(core) &amp; |N<sub>&epsilon;</sub>(p)| &lt; MinPts
              </div>
            </div>

            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
              <div className="flex items-center gap-2 font-bold text-rose-700">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-600" />
                <span>3. Noise / Anomaly (Outlier)</span>
              </div>
              <p className="text-slate-600 leading-relaxed">
                Any patient record that is neither a core point nor density-reachable from any core point is designated as <strong>noise (Cluster ID = -1)</strong>:
              </p>
              <div className="p-2 bg-white rounded border font-mono text-center text-rose-700 font-bold">
                Cluster(p) = -1 (Unusual Case)
              </div>
            </div>

          </div>

          {/* DBSCAN vs K-Means Table */}
          <div className="mt-6 border border-slate-200 rounded-xl overflow-hidden">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-100/70 border-b border-slate-200 text-slate-700 font-bold uppercase tracking-wider text-[11px]">
                  <th className="p-3">Attribute</th>
                  <th className="p-3 text-blue-700">DBSCAN (Used in this Project)</th>
                  <th className="p-3 text-slate-500">Standard K-Means</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-600">
                <tr>
                  <td className="p-3 font-semibold text-slate-800">Outlier Detection</td>
                  <td className="p-3 text-emerald-700 font-semibold bg-emerald-50/40">Isolates noise automatically as Cluster -1</td>
                  <td className="p-3 text-rose-600">Forces all outliers into regular clusters</td>
                </tr>
                <tr>
                  <td className="p-3 font-semibold text-slate-800">Cluster Count (k)</td>
                  <td className="p-3 text-emerald-700 font-semibold bg-emerald-50/40">Discovers arbitrary number of clusters automatically</td>
                  <td className="p-3 text-slate-500">Requires manual pre-specification of k</td>
                </tr>
                <tr>
                  <td className="p-3 font-semibold text-slate-800">Cluster Geometry</td>
                  <td className="p-3 text-emerald-700 font-semibold bg-emerald-50/40">Arbitrary non-linear density shapes</td>
                  <td className="p-3 text-slate-500">Assumes isotropic spherical blobs</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 3: System Requirements (Matching Slides 4 & 5) */}
      {activeTab === 'requirements' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 animate-in fade-in duration-200">
          
          {/* Software Requirements (Slide 4) */}
          <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-4">
            <div className="flex items-center gap-2.5 text-blue-600 font-bold text-base">
              <Terminal className="w-5 h-5" />
              <span>Software Requirements (Slide 4)</span>
            </div>
            
            <ul className="space-y-3 text-xs text-slate-700">
              <li className="flex items-start gap-2.5 p-2 rounded-lg bg-slate-50 border border-slate-200">
                <span className="font-bold text-blue-600">1.</span>
                <div>
                  <strong>Operating System:</strong> Windows 10/11 or Ubuntu Linux
                </div>
              </li>
              <li className="flex items-start gap-2.5 p-2 rounded-lg bg-slate-50 border border-slate-200">
                <span className="font-bold text-blue-600">2.</span>
                <div>
                  <strong>Programming Language:</strong> Python 3.10 or above
                </div>
              </li>
              <li className="flex items-start gap-2.5 p-2 rounded-lg bg-slate-50 border border-slate-200">
                <span className="font-bold text-blue-600">3.</span>
                <div>
                  <strong>Development Environment:</strong> Jupyter Notebook / Visual Studio Code
                </div>
              </li>
              <li className="flex items-start gap-2.5 p-2 rounded-lg bg-slate-50 border border-slate-200">
                <span className="font-bold text-blue-600">4.</span>
                <div>
                  <strong>Libraries:</strong> Pandas, NumPy, Scikit-learn, Matplotlib
                </div>
              </li>
              <li className="flex items-start gap-2.5 p-2 rounded-lg bg-slate-50 border border-slate-200">
                <span className="font-bold text-blue-600">5.</span>
                <div>
                  <strong>Dataset:</strong> Kaggle Disease Symptoms &amp; Patient Profile (CSV)
                </div>
              </li>
              <li className="flex items-start gap-2.5 p-2 rounded-lg bg-slate-50 border border-slate-200">
                <span className="font-bold text-blue-600">6.</span>
                <div>
                  <strong>Version Control:</strong> Git (Optional)
                </div>
              </li>
            </ul>
          </div>

          {/* Hardware Requirements (Slide 5) */}
          <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-4">
            <div className="flex items-center gap-2.5 text-purple-600 font-bold text-base">
              <HardDrive className="w-5 h-5" />
              <span>Hardware Requirements (Slide 5)</span>
            </div>

            <ul className="space-y-3 text-xs text-slate-700">
              <li className="flex items-start gap-2.5 p-2 rounded-lg bg-slate-50 border border-slate-200">
                <span className="font-bold text-purple-600">1.</span>
                <div>
                  <strong>Processor:</strong> Intel Core i3 or equivalent and above
                </div>
              </li>
              <li className="flex items-start gap-2.5 p-2 rounded-lg bg-slate-50 border border-slate-200">
                <span className="font-bold text-purple-600">2.</span>
                <div>
                  <strong>RAM:</strong> Minimum 4 GB, recommended 8 GB
                </div>
              </li>
              <li className="flex items-start gap-2.5 p-2 rounded-lg bg-slate-50 border border-slate-200">
                <span className="font-bold text-purple-600">3.</span>
                <div>
                  <strong>Storage:</strong> Minimum 10 GB free space
                </div>
              </li>
              <li className="flex items-start gap-2.5 p-2 rounded-lg bg-slate-50 border border-slate-200">
                <span className="font-bold text-purple-600">4.</span>
                <div>
                  <strong>Display:</strong> 1366 &times; 768 resolution or higher
                </div>
              </li>
              <li className="flex items-start gap-2.5 p-2 rounded-lg bg-slate-50 border border-slate-200">
                <span className="font-bold text-purple-600">5.</span>
                <div>
                  <strong>Peripherals:</strong> Standard keyboard and mouse
                </div>
              </li>
              <li className="flex items-start gap-2.5 p-2 rounded-lg bg-slate-50 border border-slate-200">
                <span className="font-bold text-purple-600">6.</span>
                <div>
                  <strong>System Architecture:</strong> 64-bit processor and operating system
                </div>
              </li>
            </ul>
          </div>

        </div>
      )}

      {/* Tab 4: Python ML Backend Code */}
      {activeTab === 'python' && (
        <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-4 animate-in fade-in duration-200">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-slate-100">
            <div>
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <Code2 className="w-5 h-5 text-blue-600" />
                <span>Python Scikit-learn DBSCAN Pipeline Script</span>
              </h3>
              <p className="text-xs text-slate-500">
                Located in <code className="bg-slate-100 px-1.5 py-0.5 rounded font-mono">backend/dbscan_model.py</code> for academic presentation and FastAPI backend serving.
              </p>
            </div>
          </div>

          <div className="relative">
            <pre className="p-4 rounded-xl bg-slate-900 text-slate-200 text-xs font-mono overflow-x-auto leading-relaxed max-h-[480px]">
              {pythonSnippet}
            </pre>
          </div>
        </div>
      )}

      {/* Safety Compliance Callout */}
      <div className="p-5 rounded-2xl bg-amber-500/10 border border-amber-300 text-xs text-amber-900 flex items-start gap-3">
        <ShieldAlert className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
        <div>
          <span className="font-bold uppercase tracking-wider block mb-1 text-amber-800">
            Mandatory Clinical Safety Notice
          </span>
          <p className="leading-relaxed">
            “This application is intended only as a machine-learning decision-support demonstration and is not a substitute for professional medical diagnosis. The website never states that an anomaly means the patient definitely has a rare disease.”
          </p>
        </div>
      </div>

    </div>
  );
}
