import React from 'react';
import { 
  Heart, 
  ExternalLink, 
  GraduationCap, 
  Binary, 
  ShieldAlert,
  Database
} from 'lucide-react';

export default function Footer({ setActivePage }) {
  return (
    <footer className="bg-slate-900 text-slate-300 pt-12 pb-8 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          
          {/* Col 1: About & Academic Guidance */}
          <div className="space-y-4">
            <div className="flex items-center gap-2 text-white font-bold text-lg">
              <span className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center text-white text-sm">
                AI
              </span>
              <span>RareCare Analytics</span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Rare-Disease Case Identification Using DBSCAN-Based Anomaly Detection. An unsupervised machine-learning decision-support system to detect atypical clinical patterns.
            </p>
            <div className="p-3 bg-slate-800/80 rounded-lg border border-slate-700/60">
              <div className="flex items-center gap-2 text-xs font-semibold text-blue-400">
                <GraduationCap className="w-4 h-4" />
                <span>Academic Guidance &amp; Mentorship</span>
              </div>
              <p className="text-xs text-white font-medium mt-1">
                Dr. Dyuti Banerjee
              </p>
              <p className="text-[11px] text-slate-400">
                Assistant Professor, AI &amp; DS
              </p>
            </div>
          </div>

          {/* Col 2: Navigation Links */}
          <div>
            <h4 className="text-white text-sm font-semibold mb-4 tracking-wide uppercase">
              System Modules
            </h4>
            <ul className="space-y-2.5 text-xs text-slate-400">
              <li>
                <button 
                  onClick={() => { setActivePage('home'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                  className="hover:text-blue-400 transition-colors"
                >
                  Overview &amp; Executive Summary
                </button>
              </li>
              <li>
                <button 
                  onClick={() => { setActivePage('patient-analysis'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                  className="hover:text-blue-400 transition-colors"
                >
                  Single-Patient Anomaly Assessment
                </button>
              </li>
              <li>
                <button 
                  onClick={() => { setActivePage('dbscan-analysis'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                  className="hover:text-blue-400 transition-colors"
                >
                  DBSCAN High-Dimensional Dashboard
                </button>
              </li>
              <li>
                <button 
                  onClick={() => { setActivePage('dataset'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                  className="hover:text-blue-400 transition-colors"
                >
                  Dataset &amp; 7-Step Preprocessing
                </button>
              </li>
              <li>
                <button 
                  onClick={() => { setActivePage('anomalies'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                  className="hover:text-blue-400 transition-colors"
                >
                  Identified Unusual Cases Table
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Research & Dataset References */}
          <div>
            <h4 className="text-white text-sm font-semibold mb-4 tracking-wide uppercase">
              Data &amp; References
            </h4>
            <div className="space-y-3 text-xs">
              <a 
                href="https://www.kaggle.com/datasets/uom190346a/disease-symptoms-and-patient-profile-dataset" 
                target="_blank" 
                rel="noopener noreferrer"
                className="flex items-center gap-2 p-2.5 rounded-lg bg-slate-800/60 border border-slate-700/50 hover:bg-slate-800 hover:border-blue-500/50 transition-colors group"
              >
                <Database className="w-4 h-4 text-blue-400 shrink-0" />
                <div className="min-w-0 flex-1">
                  <span className="text-slate-200 block truncate group-hover:text-blue-300 font-medium">Kaggle Benchmark Dataset</span>
                  <span className="text-[10px] text-slate-500">Disease Symptoms &amp; Patient Profile</span>
                </div>
                <ExternalLink className="w-3 h-3 text-slate-500 group-hover:text-blue-400 shrink-0" />
              </a>

              <div className="p-2.5 rounded-lg bg-slate-800/60 border border-slate-700/50">
                <div className="flex items-center gap-2 text-purple-400 font-medium">
                  <Binary className="w-3.5 h-3.5" />
                  <span>Unsupervised ML Focus</span>
                </div>
                <p className="text-[11px] text-slate-400 mt-1">
                  DBSCAN identifies density-reachable clusters without requiring prior rare-disease diagnosis labels.
                </p>
              </div>
            </div>
          </div>

          {/* Col 4: Safety & Ethical Disclaimer */}
          <div>
            <h4 className="text-white text-sm font-semibold mb-4 tracking-wide uppercase flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-amber-400" />
              Clinical Safety
            </h4>
            <p className="text-xs text-slate-400 leading-relaxed bg-amber-950/20 border border-amber-900/40 p-3 rounded-lg">
              <span className="text-amber-300 font-medium block mb-1">Strict Decision-Support Scope:</span>
              This system is a decision-support and anomaly-detection tool and does not replace professional medical diagnosis. Anomaly flags indicate unusual biomarker combinations warranting clinical review, not definitive rare-disease diagnosis.
            </p>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-8 mt-8 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-4">
          <div>
            &copy; {new Date().getFullYear()} Rare-Disease Case Identification Project. Academic demonstration.
          </div>
          <div className="flex items-center gap-4 text-slate-400">
            <span>Python 3.10+</span>
            <span>&bull;</span>
            <span>Scikit-learn</span>
            <span>&bull;</span>
            <span>Pandas &amp; NumPy</span>
            <span>&bull;</span>
            <span>React + Tailwind</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
