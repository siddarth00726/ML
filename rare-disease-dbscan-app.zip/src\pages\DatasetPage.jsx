import React, { useState, useRef } from 'react';
import { 
  Database, 
  Upload, 
  RefreshCw, 
  Play, 
  Filter, 
  CheckCircle2, 
  FileText, 
  Download, 
  AlertCircle, 
  Sliders, 
  Layers,
  ArrowRight,
  Sparkles
} from 'lucide-react';
import { PREPROCESSING_STEPS } from '../data/defaultParameters';
import WorkflowDiagram from '../components/WorkflowDiagram';

export default function DatasetPage({
  rawRecords,
  onResetDataset,
  onUploadCSV,
  onPreprocessAndRun,
  isProcessing,
  setActivePage
}) {
  const [activeStepTab, setActiveStepTab] = useState(1);
  const [uploadFeedback, setUploadFeedback] = useState(null);
  const fileInputRef = useRef(null);

  // CSV Upload Handler
  const handleFileChange = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const text = event.target?.result;
        if (!text || typeof text !== 'string') throw new Error("Empty file");

        const lines = text.split(/\r\n|\n/).filter(line => line.trim().length > 0);
        if (lines.length < 2) throw new Error("CSV must contain a header and at least one row");

        const headers = lines[0].split(',').map(h => h.trim().replace(/^["']|["']$/g, '').toLowerCase());
        
        const parsedRecords = [];
        for (let i = 1; i < lines.length; i++) {
          // Simple CSV splitter respecting quotes
          const match = lines[i].match(/(".*?"|[^",\s]+)(?=\s*,|\s*$)/g);
          const cols = lines[i].split(',').map(c => c.trim().replace(/^["']|["']$/g, ''));
          
          if (cols.length >= 4) {
            const ageIdx = headers.findIndex(h => h.includes('age'));
            const genderIdx = headers.findIndex(h => h.includes('gender'));
            const feverIdx = headers.findIndex(h => h.includes('fever'));
            const coughIdx = headers.findIndex(h => h.includes('cough'));
            const fatigueIdx = headers.findIndex(h => h.includes('fatigue'));
            const breathIdx = headers.findIndex(h => h.includes('breath') || h.includes('dyspnea'));
            const bpIdx = headers.findIndex(h => h.includes('blood') || h.includes('pressure') || h.includes('bp'));
            const cholIdx = headers.findIndex(h => h.includes('cholesterol'));
            const diseaseIdx = headers.findIndex(h => h.includes('disease') || h.includes('condition'));
            const outcomeIdx = headers.findIndex(h => h.includes('outcome') || h.includes('test'));

            parsedRecords.push({
              id: `UP-${1000 + i}`,
              age: ageIdx !== -1 && cols[ageIdx] ? Number(cols[ageIdx]) : 35,
              gender: genderIdx !== -1 && cols[genderIdx] ? cols[genderIdx] : "Unspecified",
              fever: feverIdx !== -1 && cols[feverIdx]?.toLowerCase().startsWith('y') ? "Yes" : "No",
              cough: coughIdx !== -1 && cols[coughIdx]?.toLowerCase().startsWith('y') ? "Yes" : "No",
              fatigue: fatigueIdx !== -1 && cols[fatigueIdx]?.toLowerCase().startsWith('y') ? "Yes" : "No",
              difficultyBreathing: breathIdx !== -1 && cols[breathIdx]?.toLowerCase().startsWith('y') ? "Yes" : "No",
              bloodPressure: bpIdx !== -1 && cols[bpIdx] ? cols[bpIdx] : "Normal",
              cholesterol: cholIdx !== -1 && cols[cholIdx] ? cols[cholIdx] : "Normal",
              testResult: outcomeIdx !== -1 && cols[outcomeIdx] ? cols[outcomeIdx] : "Positive",
              medicalCondition: diseaseIdx !== -1 && cols[diseaseIdx] ? cols[diseaseIdx] : "Uploaded Case",
              medicalHistory: "Imported via custom CSV upload."
            });
          }
        }

        if (parsedRecords.length > 0) {
          onUploadCSV(parsedRecords);
          setUploadFeedback({
            type: 'success',
            message: `Successfully loaded ${parsedRecords.length} patient records from ${file.name}.`
          });
        } else {
          throw new Error("Could not parse valid records. Check CSV headers.");
        }
      } catch (err) {
        setUploadFeedback({
          type: 'error',
          message: `CSV Parse Error: ${err.message || "Invalid format"}`
        });
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="space-y-8 pb-12">
      
      {/* Page Header */}
      <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 text-blue-700 border border-blue-200 text-xs font-semibold mb-2">
            <Database className="w-3.5 h-3.5" />
            <span>Healthcare Data Repository</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900">
            Dataset Management &amp; Preprocessing
          </h1>
          <p className="text-sm text-slate-500 mt-1 max-w-2xl">
            Sourced from the Kaggle <em>Disease Symptoms and Patient Profile Dataset</em>. Inspect raw observations, execute the 7-stage clinical cleaning pipeline, and trigger DBSCAN clustering.
          </p>
        </div>

        {/* 4 Action Buttons Required by Section 6 */}
        <div className="flex flex-wrap items-center gap-2.5">
          
          {/* Upload CSV */}
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            accept=".csv"
            className="hidden"
          />
          <button
            onClick={() => fileInputRef.current?.click()}
            className="px-3.5 py-2 bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 rounded-xl text-xs font-semibold flex items-center gap-2 shadow-xs transition-colors"
          >
            <Upload className="w-3.5 h-3.5 text-blue-600" />
            <span>Upload CSV</span>
          </button>

          {/* Load Dataset */}
          <button
            onClick={onResetDataset}
            className="px-3.5 py-2 bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 rounded-xl text-xs font-semibold flex items-center gap-2 shadow-xs transition-colors"
          >
            <RefreshCw className="w-3.5 h-3.5 text-slate-500" />
            <span>Load Kaggle Dataset</span>
          </button>

          {/* Preprocess Data */}
          <button
            onClick={() => onPreprocessAndRun(false)}
            disabled={isProcessing}
            className="px-3.5 py-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 rounded-xl text-xs font-semibold flex items-center gap-2 transition-colors disabled:opacity-60"
          >
            <Filter className="w-3.5 h-3.5 text-indigo-600" />
            <span>Preprocess Data</span>
          </button>

          {/* Run DBSCAN */}
          <button
            onClick={() => {
              onPreprocessAndRun(true);
              setActivePage('dbscan-analysis');
            }}
            disabled={isProcessing}
            className="px-4 py-2 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white rounded-xl text-xs font-bold flex items-center gap-2 shadow-md shadow-blue-500/25 transition-all transform hover:-translate-y-0.5 disabled:opacity-60"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>Run DBSCAN</span>
          </button>

        </div>
      </div>

      {/* Upload Feedback Notice */}
      {uploadFeedback && (
        <div className={`p-4 rounded-xl border flex items-center justify-between text-xs font-medium ${
          uploadFeedback.type === 'success' 
            ? 'bg-emerald-50 border-emerald-200 text-emerald-800' 
            : 'bg-rose-50 border-rose-200 text-rose-800'
        }`}>
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4" />
            <span>{uploadFeedback.message}</span>
          </div>
          <button 
            onClick={() => setUploadFeedback(null)}
            className="text-xs hover:underline font-bold"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Preprocessing Steps Section (Section 6 requirement: 1-7 steps display) */}
      <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-xs space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-4 border-b border-slate-100">
          <div>
            <span className="text-xs font-bold text-blue-600 uppercase tracking-wider">
              Data Cleaning &amp; Feature Engineering
            </span>
            <h3 className="text-lg font-bold text-slate-800 mt-1">
              7-Step Clinical Preprocessing Pipeline
            </h3>
          </div>
          <span className="text-xs text-slate-400 font-mono">
            Pipeline: 100% Automated &bull; Zero Leakage
          </span>
        </div>

        {/* Steps Navigation / Stepper */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-7 gap-2.5">
          {PREPROCESSING_STEPS.map((s) => (
            <button
              key={s.step}
              onClick={() => setActiveStepTab(s.step)}
              className={`p-3 rounded-xl text-left border transition-all ${
                activeStepTab === s.step
                  ? 'bg-blue-600 text-white border-blue-600 shadow-sm shadow-blue-500/30'
                  : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <span className={`text-[10px] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded-md ${
                  activeStepTab === s.step ? 'bg-white/20 text-white' : 'bg-slate-200 text-slate-600'
                }`}>
                  Step {s.step}
                </span>
                <CheckCircle2 className={`w-3.5 h-3.5 ${activeStepTab === s.step ? 'text-blue-200' : 'text-emerald-500'}`} />
              </div>
              <div className="text-xs font-bold truncate">{s.name}</div>
            </button>
          ))}
        </div>

        {/* Selected Step Explanation Card */}
        {(() => {
          const step = PREPROCESSING_STEPS.find(s => s.step === activeStepTab) || PREPROCESSING_STEPS[0];
          return (
            <div className="p-5 rounded-xl bg-slate-50 border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="space-y-1">
                <div className="text-xs font-bold text-blue-700 uppercase tracking-wide">
                  Step {step.step}: {step.name}
                </div>
                <p className="text-xs text-slate-600 max-w-3xl leading-relaxed">
                  {step.description}
                </p>
              </div>
              <div className="px-3 py-1.5 rounded-lg bg-white border border-slate-200 text-[11px] font-semibold text-slate-600 shrink-0 self-start sm:self-auto">
                Status: Applied to Matrix
              </div>
            </div>
          );
        })()}
      </div>

      {/* Sample Patient Dataset Records Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        
        <div className="p-6 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-base font-bold text-slate-800">
              Healthcare Patient Records
            </h3>
            <p className="text-xs text-slate-500">
              Showing {rawRecords.length} records. Includes demographic profiles, symptoms, and physiological markers.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-500">Dataset Format:</span>
            <span className="px-2 py-0.5 bg-slate-100 text-slate-700 text-xs font-mono font-semibold rounded-md">
              Kaggle Clinical CSV
            </span>
          </div>
        </div>

        <div className="overflow-x-auto max-h-[480px]">
          <table className="w-full text-left border-collapse">
            <thead className="sticky top-0 bg-slate-50 border-b border-slate-200 text-[11px] font-bold text-slate-600 uppercase tracking-wider z-10">
              <tr>
                <th className="py-3 px-4 sm:px-6">ID</th>
                <th className="py-3 px-3">Age</th>
                <th className="py-3 px-3">Gender</th>
                <th className="py-3 px-3">Fever</th>
                <th className="py-3 px-3">Cough</th>
                <th className="py-3 px-3">Fatigue</th>
                <th className="py-3 px-3">Dyspnea</th>
                <th className="py-3 px-3">Blood Pressure</th>
                <th className="py-3 px-3">Cholesterol</th>
                <th className="py-3 px-4">Medical Condition</th>
                <th className="py-3 px-3">Outcome</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-xs text-slate-700">
              {rawRecords.slice(0, 40).map((record) => (
                <tr key={record.id} className="hover:bg-slate-50/80 transition-colors">
                  <td className="py-3 px-4 sm:px-6 font-mono font-bold text-slate-900">
                    {record.id}
                  </td>
                  <td className="py-3 px-3 font-semibold">{record.age}</td>
                  <td className="py-3 px-3 text-slate-600">{record.gender}</td>
                  <td className="py-3 px-3">
                    <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                      record.fever === 'Yes' ? 'bg-amber-100 text-amber-800' : 'text-slate-400'
                    }`}>
                      {record.fever}
                    </span>
                  </td>
                  <td className="py-3 px-3">
                    <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                      record.cough === 'Yes' ? 'bg-blue-100 text-blue-800' : 'text-slate-400'
                    }`}>
                      {record.cough}
                    </span>
                  </td>
                  <td className="py-3 px-3">
                    <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                      record.fatigue === 'Yes' ? 'bg-purple-100 text-purple-800' : 'text-slate-400'
                    }`}>
                      {record.fatigue}
                    </span>
                  </td>
                  <td className="py-3 px-3">
                    <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                      record.difficultyBreathing === 'Yes' ? 'bg-rose-100 text-rose-800' : 'text-slate-400'
                    }`}>
                      {record.difficultyBreathing}
                    </span>
                  </td>
                  <td className="py-3 px-3 font-medium">
                    <span className={record.bloodPressure === 'High' ? 'text-rose-600 font-bold' : 'text-slate-700'}>
                      {record.bloodPressure}
                    </span>
                  </td>
                  <td className="py-3 px-3 font-medium">
                    <span className={record.cholesterol === 'High' ? 'text-amber-700 font-bold' : 'text-slate-700'}>
                      {record.cholesterol}
                    </span>
                  </td>
                  <td className="py-3 px-4 font-medium text-slate-800 max-w-xs truncate">
                    {record.medicalCondition}
                  </td>
                  <td className="py-3 px-3">
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-semibold ${
                      record.testResult === 'Positive' ? 'bg-rose-50 text-rose-700 border border-rose-200' : 'bg-slate-100 text-slate-600'
                    }`}>
                      {record.testResult}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="p-4 bg-slate-50 border-t border-slate-200 text-xs text-slate-500 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <span>Displaying first 40 records for responsiveness ({rawRecords.length} total in memory).</span>
          <button
            onClick={() => {
              onPreprocessAndRun(true);
              setActivePage('dbscan-analysis');
            }}
            className="text-xs text-blue-600 font-bold hover:underline inline-flex items-center gap-1"
          >
            <span>Proceed to DBSCAN Cluster Dashboard</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

      </div>

      {/* Visual Workflow Diagram */}
      <div>
        <WorkflowDiagram />
      </div>

    </div>
  );
}
