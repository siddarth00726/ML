"""
FastAPI Server for Rare-Disease Case Identification using DBSCAN
Run: uvicorn app:app --reload --port 8000
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, List
import pandas as pd
from dbscan_model import RareDiseaseDBSCANDetector

app = FastAPI(
    title="Rare-Disease Case Identification API",
    description="DBSCAN-based Anomaly Detection Decision Support API",
    version="1.0.0"
)

# Enable CORS for React frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

detector = RareDiseaseDBSCANDetector(eps=1.30, min_samples=4)

class PatientInput(BaseModel):
    id: Optional[str] = "PT-NEW"
    Age: float
    Gender: Optional[str] = "Male"
    Fever: str
    Cough: str
    Fatigue: str
    Difficulty_Breathing: str
    Blood_Pressure: str
    Cholesterol_Level: str
    Outcome_Variable: Optional[str] = "Positive"

@app.get("/")
def read_root():
    return {
        "title": "Rare-Disease Case Identification Using DBSCAN-Based Anomaly Detection",
        "guidance": "Dr. Dyuti Banerjee, Assistant Professor AI & DS",
        "status": "online",
        "disclaimer": "This application is intended only as a machine-learning decision-support demonstration and is not a substitute for professional medical diagnosis."
    }

@app.post("/api/predict")
def predict_patient(patient: PatientInput):
    data_dict = {
        "id": patient.id,
        "Age": patient.Age,
        "Gender": patient.Gender,
        "Fever": patient.Fever,
        "Cough": patient.Cough,
        "Fatigue": patient.Fatigue,
        "Difficulty Breathing": patient.Difficulty_Breathing,
        "Blood Pressure": patient.Blood_Pressure,
        "Cholesterol Level": patient.Cholesterol_Level,
        "Outcome Variable": patient.Outcome_Variable
    }
    result = detector.evaluate_new_patient(data_dict)
    return result

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
