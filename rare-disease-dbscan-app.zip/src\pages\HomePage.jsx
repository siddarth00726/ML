import React from 'react';
import { 
  Activity, 
  ArrowRight, 
  ShieldAlert, 
  Cpu, 
  ScatterChart, 
  Search, 
  Layers, 
  CheckCircle2, 
  TrendingUp, 
  Sparkles,
  FileText,
  UserCheck,
  Stethoscope
} from 'lucide-react';
import WorkflowDiagram from '../components/WorkflowDiagram';

export default function HomePage({ setActivePage, metrics }) {
  const featureCards = [
    {
      title: "Patient Data Analysis",
      icon: Activity,
      color: "from-blue-600 to-indigo-600",
      description: "Standardizes high-dimensional clinical profiles across symptoms, vitals, medical history, and age-related biomarkers."
    },
    {
      title: "DBSCAN Clustering",
      icon: Layers,
      color: "from-indigo-600 to-purple-600",
      description: "Employs density-reachability algorithms to autonomously group patients with common underlying pathophysiological profiles."
    },
    {
      title: "Anomaly Detection",
      icon: Search,
      color: "from-purple-600 to-pink-600",
      description: "Isolates points in sparse feature space that fail to satisfy minimum point density thresholds (&epsilon; and MinPts)."
    },
    {
      title: "Healthcare Insights",
      icon: TrendingUp,
      color: "from-cyan-600 to-blue-600",
      description: "Provides objective decision-support cues to help clinicians identify atypical cases early before severe progression."
    }
  ];

  return (
    <div className="space-y-12 pb-12">
      
      {/* Hero Section */}
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-blue-900 via-indigo-900 to-slate-950 text-white p-8 sm:p-12 lg:p-16 shadow-xl border border-indigo-800/40">
        
        {/* Subtle background glow effect */}
        <div className="absolute -top-24 -right-24 w-96 h-96 bg-blue-500/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -left-24 w-96 h-96 bg-purple-500/20 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 max-w-4xl">
          
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/10 backdrop-blur-md border border-white/15 text-xs font-semibold text-blue-200 mb-6 shadow-xs">
            <Sparkles className="w-3.5 h-3.5 text-blue-300 animate-pulse" />
            <span>AI-Driven Clinical Decision Support System</span>
          </div>

          {/* Title & Subtitle */}
          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white leading-tight">
            Rare-Disease Case <span className="bg-gradient-to-r from-blue-400 via-indigo-300 to-purple-300 bg-clip-text text-transparent">Identification</span>
          </h1>
          
          <h2 className="text-lg sm:text-2xl font-medium text-blue-100/90 mt-4 leading-relaxed max-w-3xl">
            DBSCAN-Based Anomaly Detection for Early Identification of Unusual Healthcare Patterns
          </h2>

          {/* Problem Statement Paragraph */}
          <p className="text-sm sm:text-base text-slate-300 mt-6 leading-relaxed max-w-2xl">
            Rare diseases are notoriously challenging to identify because their early clinical symptoms frequently resemble prevalent, common medical conditions. By applying unsupervised density clustering, this system isolates non-conforming patient profiles without requiring scarce labeled training data.
          </p>

          {/* CTA Action Buttons */}
          <div className="flex flex-wrap items-center gap-4 mt-8">
            <button
              onClick={() => { setActivePage('patient-analysis'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
              className="px-6 py-3.5 rounded-xl bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 text-white font-semibold text-sm shadow-lg shadow-blue-500/30 flex items-center gap-2 transform hover:-translate-y-0.5 transition-all duration-200"
            >
              <UserCheck className="w-4 h-4" />
              <span>Analyze Patient</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={() => { setActivePage('dbscan-analysis'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
              className="px-6 py-3.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-semibold text-sm backdrop-blur-md border border-white/20 flex items-center gap-2 transform hover:-translate-y-0.5 transition-all duration-200"
            >
              <ScatterChart className="w-4 h-4 text-purple-300" />
              <span>View Dashboard</span>
            </button>

            <button
              onClick={() => { setActivePage('dataset'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
              className="px-5 py-3.5 rounded-xl text-slate-300 hover:text-white text-sm font-medium flex items-center gap-1.5 transition-colors"
            >
              <FileText className="w-4 h-4" />
              <span>Explore Dataset</span>
            </button>
          </div>

          {/* Primary Disclaimer Box */}
          <div className="mt-10 p-4 rounded-xl bg-amber-500/15 border border-amber-400/30 text-xs sm:text-sm text-amber-200/95 flex items-start gap-3">
            <ShieldAlert className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
            <div>
              <span className="font-semibold text-amber-300 uppercase tracking-wide text-xs block mb-0.5">
                Clinical Usage Disclaimer
              </span>
              <p className="leading-snug">
                “This system is a decision-support tool and does not replace professional medical diagnosis.” It flags statistical divergence in multi-dimensional feature space to encourage thorough multidisciplinary physician assessment.
              </p>
            </div>
          </div>

        </div>

      </section>

      {/* Real-Time Metrics Highlights Bar */}
      <section className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
            <Activity className="w-6 h-6" />
          </div>
          <div>
            <div className="text-2xl font-extrabold text-slate-900">{metrics.totalPatients}</div>
            <div className="text-xs font-medium text-slate-500">Patient Records Analyzed</div>
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center shrink-0">
            <Layers className="w-6 h-6" />
          </div>
          <div>
            <div className="text-2xl font-extrabold text-purple-700">{metrics.numClusters}</div>
            <div className="text-xs font-medium text-slate-500">Dense Clinical Cohorts</div>
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center shrink-0">
            <Search className="w-6 h-6" />
          </div>
          <div>
            <div className="text-2xl font-extrabold text-rose-600">{metrics.numAnomalies}</div>
            <div className="text-xs font-medium text-slate-500">Unusual Cases Detected</div>
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
            <CheckCircle2 className="w-6 h-6" />
          </div>
          <div>
            <div className="text-2xl font-extrabold text-emerald-600">{metrics.normalCases}</div>
            <div className="text-xs font-medium text-slate-500">Conforming Regular Cases</div>
          </div>
        </div>
      </section>

      {/* Feature Cards Section */}
      <section className="space-y-6">
        <div className="text-center max-w-2xl mx-auto">
          <span className="text-xs font-bold uppercase tracking-wider text-blue-600 bg-blue-50 px-3 py-1 rounded-full border border-blue-200">
            Core Capabilities
          </span>
          <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-2">
            AI-Enhanced Rare Disease Detection
          </h3>
          <p className="text-sm text-slate-500 mt-2">
            Transforming subtle clinical patterns into actionable, early decision-support alerts.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {featureCards.map((card, idx) => {
            const Icon = card.icon;
            return (
              <div 
                key={idx}
                className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs hover:shadow-lg transition-all duration-300 flex flex-col group hover:-translate-y-1"
              >
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-tr ${card.color} flex items-center justify-center text-white shadow-md mb-5 group-hover:scale-110 transition-transform duration-200`}>
                  <Icon className="w-6 h-6" />
                </div>
                <h4 className="text-base font-bold text-slate-800 mb-2 group-hover:text-blue-600 transition-colors">
                  {card.title}
                </h4>
                <p className="text-xs text-slate-500 leading-relaxed mt-auto">
                  {card.description}
                </p>
              </div>
            );
          })}
        </div>
      </section>

      {/* Visual Workflow Section */}
      <section>
        <WorkflowDiagram />
      </section>

      {/* Clinical Motivation & Why DBSCAN */}
      <section className="grid grid-cols-1 lg:grid-cols-2 gap-8 bg-white rounded-3xl p-8 border border-slate-200 shadow-xs">
        <div className="space-y-4">
          <span className="text-xs font-bold uppercase tracking-wider text-purple-600 bg-purple-50 px-3 py-1 rounded-full border border-purple-200">
            Clinical Rationale
          </span>
          <h3 className="text-xl sm:text-2xl font-bold text-slate-900">
            Overcoming the "Diagnostic Odyssey" in Rare Diseases
          </h3>
          <p className="text-sm text-slate-600 leading-relaxed">
            Patients suffering from rare illnesses visit an average of 7.3 physicians and endure 4.8 years of misdiagnoses before receiving an accurate medical evaluation. Because individual rare conditions affect fewer than 1 in 2,000 individuals, classical supervised machine-learning algorithms suffer from severe class imbalance and extreme lack of labeled training instances.
          </p>
          <p className="text-sm text-slate-600 leading-relaxed">
            By shifting from supervised classification to <strong>unsupervised density-based outlier detection (DBSCAN)</strong>, we circumvent the need for pre-existing disease labels. The model instead learns what dense normality looks like across common ailments, and surfaces rare anomalies purely through their spatial isolation in high-dimensional biomarker space.
          </p>
        </div>

        <div className="space-y-4 bg-slate-50 p-6 rounded-2xl border border-slate-200">
          <h4 className="text-sm font-bold text-slate-800 uppercase tracking-wide flex items-center gap-2">
            <Cpu className="w-4 h-4 text-blue-600" />
            Key DBSCAN Mathematical Pillars
          </h4>
          <ul className="space-y-3 text-xs text-slate-600">
            <li className="flex items-start gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-blue-600 mt-1.5 shrink-0" />
              <div>
                <strong className="text-slate-800">&epsilon;-Neighborhood (Radius):</strong> Defines the maximum Euclidean distance threshold within which two patient records are considered clinically similar.
              </div>
            </li>
            <li className="flex items-start gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-purple-600 mt-1.5 shrink-0" />
              <div>
                <strong className="text-slate-800">MinPts (Core Density):</strong> Minimum required patient volume in an &epsilon;-sphere to form an established clinical cluster.
              </div>
            </li>
            <li className="flex items-start gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-rose-600 mt-1.5 shrink-0" />
              <div>
                <strong className="text-slate-800">Noise Points (Anomalies):</strong> Isolated patients that are neither core points nor density-reachable from any core point. These constitute candidate unusual or rare-disease cases.
              </div>
            </li>
          </ul>

          <div className="pt-2">
            <button
              onClick={() => { setActivePage('dbscan-analysis'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
              className="text-xs font-semibold text-blue-600 hover:text-blue-800 flex items-center gap-1 group"
            >
              <span>Explore DBSCAN 2D Spatial Dashboard &amp; Analysis</span>
              <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>
        </div>
      </section>

    </div>
  );
}
