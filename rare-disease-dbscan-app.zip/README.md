# Rare-Disease Case Identification Using DBSCAN-Based Anomaly Detection

**Academic Guidance & Mentorship:** Dr. Dyuti Banerjee, Assistant Professor AI & DS  
**Decision-Support Notice:** *This system is a decision-support and anomaly-detection demonstration tool and does not replace professional medical diagnosis.*

---

## 🔬 Project Overview
Rare diseases are challenging to identify early because their initial clinical symptoms frequently overlap with common medical conditions. Traditional supervised machine-learning models fail due to severe class imbalance and the lack of comprehensive disease labels.

This project implements an unsupervised **DBSCAN (Density-Based Spatial Clustering of Applications with Noise)** anomaly detection architecture. It groups conforming patient records into dense clinical clusters and automatically isolates low-density, spatially disconnected records as potential unusual cases (`Cluster ID = -1`), signaling them for multidisciplinary clinical examination.

---

## 🌟 Key Application Features

1. **AI & Medical UI Design:**
   - Professional light theme with clinical royal blue (`#1e40af`) and deep purple accents.
   - Fully responsive layout across desktop, tablet, and mobile.
   - Smooth glassmorphism, animated cards, and metric counters.

2. **6 Core Integrated Pages:**
   - **Home:** Landing page with executive overview, value proposition, feature cards, and safety notices.
   - **Patient Analysis:** Clinical intake form for real-time patient assessment against the fitted high-dimensional DBSCAN model space.
   - **Dataset:** Kaggle benchmark dataset viewer, CSV file upload, and 7-stage preprocessing pipeline visualizer.
   - **DBSCAN Analysis:** Interactive 2D scatter plot, normal vs. anomaly doughnut chart, cluster membership breakdown, and age distribution histogram.
   - **Anomalies:** Dedicated table of detected unusual cases with search, cluster filters, patient inspection modal, and CSV export.
   - **About Project:** Mathematical explanation of DBSCAN, system hardware/software specifications (Slides 4 & 5), and academic mentorship documentation.

3. **Interactive DBSCAN Hyperparameter Tuning:**
   - Real-time sliders for Epsilon ($\varepsilon$) and MinPts ($min\_samples$) that instantly re-cluster data points in memory.

4. **Dual Engine Implementation:**
   - **In-Browser ML Engine (`src/ml/`):** Real-time JavaScript DBSCAN algorithm executing pairwise Euclidean distances, core point identification, and cluster expansion.
   - **Python Scikit-learn Backend (`backend/`):** Complete Python ML script (`dbscan_model.py`) and FastAPI server (`app.py`).

---

## 🛠️ Technology Stack

- **Frontend:** React 19, Vite, Tailwind CSS, Lucide React
- **Machine Learning (Client):** Custom in-browser DBSCAN clustering engine & Z-Score standardizer
- **Machine Learning (Python Backend):** Python 3.10+, Pandas, NumPy, Scikit-learn, Scipy, Matplotlib, FastAPI, Uvicorn
- **Dataset Reference:** [Kaggle Disease Symptoms and Patient Profile Dataset](https://www.kaggle.com/datasets/uom190346a/disease-symptoms-and-patient-profile-dataset)

---

## 🚀 Getting Started

### 1. Run the Web Application

```bash
cd C:\Users\manikanta\.gemini\antigravity\scratch\rare-disease-dbscan-app

# Install dependencies (already installed)
npm install

# Start Vite Development Server
npm run dev
# Or preview the production build
npm run preview
```

Open your browser at `http://localhost:5173`.

### 2. (Optional) Run the Python Backend

```bash
cd backend

# Create virtual environment and install packages
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt

# Run DBSCAN standalone test
python dbscan_model.py

# Run FastAPI REST API server
uvicorn app:app --reload --port 8000
```

---

## 📋 7-Step Preprocessing Pipeline
1. **Remove duplicate records:** Eliminates identical entries to avoid artificial density concentration.
2. **Handle missing values:** Imputes median for numerical Age and mode for categorical symptoms.
3. **Correct data types:** Enforces strict numeric types and standardized categorical strings.
4. **Encode categorical values:** Maps symptoms to binary indicators and vitals to ordinal vectors.
5. **Check invalid values:** Verifies biological plausibility (e.g., Age between 1 and 120).
6. **Select relevant features:** Focuses on salient biomarkers and physiological symptoms.
7. **Standardize numerical features:** Applies Z-Score standardization ($\mu = 0, \sigma = 1$) to preserve Euclidean metric balance.

---

## ⚠️ Mandatory Safety Notice
> **Clinical Disclaimer:** This application is intended only as a machine-learning decision-support demonstration and is not a substitute for professional medical diagnosis. The application strictly avoids claiming that an anomaly implies a confirmed rare disease, instead recommending further specialized medical evaluation.
