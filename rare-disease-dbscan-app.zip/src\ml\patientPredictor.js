// Predictor for single new patient intake using fitted DBSCAN model space

import { euclideanDistance } from './dbscanEngine';

export function predictPatientAnomaly(patientInput, clusteredRecords, scalerStats, eps = 1.30) {
  if (!clusteredRecords || clusteredRecords.length === 0) {
    return {
      clusterId: -1,
      isAnomaly: true,
      anomalyScore: 0.95,
      riskLevel: "High Unusual Alert",
      alertStatus: "Warning",
      recommendation: "Baseline cohort model not loaded. Please initialize the dataset before analyzing patient."
    };
  }

  // Parse and standardize patient inputs
  const parsedAge = Number(patientInput.age) || 40;
  const meanAge = scalerStats?.meanAge || 45;
  const stdAge = scalerStats?.stdAge || 15;
  const standardizedAge = (parsedAge - meanAge) / stdAge;

  const feverVal = (patientInput.fever && patientInput.fever.toLowerCase() === 'yes') ? 1.0 : 0.0;
  const coughVal = (patientInput.cough && patientInput.cough.toLowerCase() === 'yes') ? 1.0 : 0.0;
  const fatigueVal = (patientInput.fatigue && patientInput.fatigue.toLowerCase() === 'yes') ? 1.0 : 0.0;
  const breathingVal = (patientInput.difficultyBreathing && patientInput.difficultyBreathing.toLowerCase() === 'yes') ? 1.0 : 0.0;

  let bpVal = 0.0;
  const bpStr = (patientInput.bloodPressure || '').toLowerCase();
  if (bpStr === 'high') bpVal = 1.0;
  else if (bpStr === 'elevated') bpVal = 0.5;

  const cholVal = (patientInput.cholesterol || '').toLowerCase() === 'high' ? 1.0 : 0.0;
  const outcomeVal = (patientInput.testResult || '').toLowerCase() === 'positive' ? 1.0 : 0.0;

  const patientVector = [
    standardizedAge * 1.2,
    feverVal,
    coughVal,
    fatigueVal,
    breathingVal,
    bpVal,
    cholVal,
    outcomeVal
  ];

  // Find distance to all core points and normal points
  let minCoreDistance = Infinity;
  let nearestCluster = -1;
  let nearestPatient = null;
  let minAnyDistance = Infinity;

  for (const record of clusteredRecords) {
    if (!record.encodedVector) continue;
    const dist = euclideanDistance(patientVector, record.encodedVector);

    if (dist < minAnyDistance) {
      minAnyDistance = dist;
      nearestPatient = record;
    }

    // Check core points distance
    if (record.isCore && dist < minCoreDistance) {
      minCoreDistance = dist;
      nearestCluster = record.cluster;
    }
  }

  // If no core points, check nearest normal patient
  if (minCoreDistance === Infinity && nearestPatient) {
    minCoreDistance = minAnyDistance;
    nearestCluster = nearestPatient.cluster;
  }

  // DBSCAN Decision Rule:
  // If distance to nearest core point <= eps, patient is within density reachability of an existing cluster
  const isAnomaly = minCoreDistance > eps;
  const finalCluster = isAnomaly ? -1 : nearestCluster;

  // Normalized Anomaly Score (0.0 to 1.0 scale)
  // Scores above (eps / 2) start to show variance; > eps is flagged as anomaly
  const rawScore = minCoreDistance / (eps * 1.8);
  const normalizedScore = Math.min(Math.max(rawScore, 0.05), 0.99);

  let riskLevel = "Normal Pattern";
  let alertIndicator = "Low Variance (Typical Profile)";
  let badgeColor = "bg-emerald-100 text-emerald-800 border-emerald-300";
  let recommendation = "Patient biomarkers and symptom combinations conform to observed cohort patterns. Continue standard standard-of-care monitoring and follow-up.";

  if (isAnomaly) {
    riskLevel = "Potential Unusual Case";
    alertIndicator = "High Isolation / Density Outlier";
    badgeColor = "bg-rose-100 text-rose-800 border-rose-300";
    recommendation = "Potential unusual case detected — further medical examination recommended. The clinical combination of symptoms and biomarkers deviates significantly from established population clusters. Referral to a specialist or multidisciplinary clinical case conference is advised.";
  } else if (normalizedScore > 0.65) {
    riskLevel = "Borderline Variation";
    alertIndicator = "Moderate Variance from Cluster Center";
    badgeColor = "bg-amber-100 text-amber-800 border-amber-300";
    recommendation = "Patient lies on the periphery of an established clinical cluster. Re-evaluation of vital signs and repeating baseline laboratory tests within 2 weeks is suggested.";
  }

  return {
    patientId: patientInput.id || "PT-NEW",
    clusterId: finalCluster,
    isAnomaly,
    anomalyScore: Number(normalizedScore.toFixed(3)),
    coreDistance: Number(minCoreDistance.toFixed(3)),
    riskLevel,
    alertIndicator,
    badgeColor,
    recommendation,
    nearestCohortMatch: nearestPatient ? nearestPatient.medicalCondition : "Unknown",
    timestamp: new Date().toISOString()
  };
}
