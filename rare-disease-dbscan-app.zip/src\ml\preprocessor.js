// Preprocessing pipeline implementation following the 7 steps:
// 1. Remove duplicate records
// 2. Handle missing values
// 3. Correct data types
// 4. Encode categorical values
// 5. Check invalid values
// 6. Select relevant features
// 7. Standardize numerical features

export function preprocessDataset(rawRecords) {
  if (!rawRecords || rawRecords.length === 0) {
    return { cleanedRecords: [], featureMatrix: [], scalerStats: null, pcaCoordinates: [] };
  }

  // Step 1: Remove duplicates (based on ID or full JSON signature)
  const seenIds = new Set();
  const deduped = [];
  for (const item of rawRecords) {
    const id = item.id || `AUTO-${Math.random().toString(36).substring(2, 7)}`;
    if (!seenIds.has(id)) {
      seenIds.add(id);
      deduped.push({ ...item, id });
    }
  }

  // Step 2 & 3: Correct types and handle missing values
  // Calculate mean and std for Age
  const ages = deduped
    .map(p => Number(p.age))
    .filter(a => !isNaN(a) && a > 0 && a <= 120);
  
  const meanAge = ages.length > 0 ? ages.reduce((a, b) => a + b, 0) / ages.length : 45;
  const varianceAge = ages.length > 1
    ? ages.reduce((a, b) => a + Math.pow(b - meanAge, 2), 0) / (ages.length - 1)
    : 15;
  const stdAge = Math.sqrt(varianceAge) || 1;

  const scalerStats = {
    meanAge: Number(meanAge.toFixed(2)),
    stdAge: Number(stdAge.toFixed(2))
  };

  // Step 4 & 5 & 6: Encode categorical and select features
  // Binary / Ordinal Encoding:
  // Fever: Yes=1, No=0
  // Cough: Yes=1, No=0
  // Fatigue: Yes=1, No=0
  // Difficulty Breathing: Yes=1, No=0
  // Blood Pressure: High=1, Elevated=0.5, Normal=0
  // Cholesterol: High=1, Normal=0
  // Outcome/TestResult: Positive=1, Negative=0
  // Standardized Age: (Age - meanAge) / stdAge

  const cleanedRecords = [];
  const featureMatrix = [];

  for (const item of deduped) {
    let parsedAge = Number(item.age);
    if (isNaN(parsedAge) || parsedAge <= 0 || parsedAge > 120) {
      parsedAge = Math.round(meanAge);
    }

    const feverVal = (item.fever && item.fever.toString().toLowerCase() === 'yes') ? 1.0 : 0.0;
    const coughVal = (item.cough && item.cough.toString().toLowerCase() === 'yes') ? 1.0 : 0.0;
    const fatigueVal = (item.fatigue && item.fatigue.toString().toLowerCase() === 'yes') ? 1.0 : 0.0;
    const breathingVal = (item.difficultyBreathing && item.difficultyBreathing.toString().toLowerCase() === 'yes') ? 1.0 : 0.0;

    let bpVal = 0.0;
    const bpStr = (item.bloodPressure || '').toString().toLowerCase();
    if (bpStr === 'high') bpVal = 1.0;
    else if (bpStr === 'elevated') bpVal = 0.5;

    const cholVal = (item.cholesterol || '').toString().toLowerCase() === 'high' ? 1.0 : 0.0;
    const outcomeVal = (item.testResult || '').toString().toLowerCase() === 'positive' ? 1.0 : 0.0;

    // Step 7: Standardize numerical Age (scaled with weight 1.2 to give realistic distance spread)
    const standardizedAge = (parsedAge - scalerStats.meanAge) / scalerStats.stdAge;

    // Vector representation for DBSCAN:
    // [stdAge, fever, cough, fatigue, breathing, bp, chol, outcome]
    const vector = [
      standardizedAge * 1.2,
      feverVal,
      coughVal,
      fatigueVal,
      breathingVal,
      bpVal,
      cholVal,
      outcomeVal
    ];

    const cleanItem = {
      ...item,
      age: parsedAge,
      standardizedAge: Number(standardizedAge.toFixed(3)),
      encodedVector: vector
    };

    cleanedRecords.push(cleanItem);
    featureMatrix.push(vector);
  }

  // Compute 2D Projection for Visual Scatter Plot (PCA 2-Component approximation)
  const pcaCoordinates = computePca2D(featureMatrix);

  // Attach PCA coords to cleaned records
  cleanedRecords.forEach((record, idx) => {
    record.pcaX = pcaCoordinates[idx] ? pcaCoordinates[idx].x : 0;
    record.pcaY = pcaCoordinates[idx] ? pcaCoordinates[idx].y : 0;
  });

  return {
    cleanedRecords,
    featureMatrix,
    scalerStats,
    pcaCoordinates
  };
}

// Lightweight 2D PCA / Principal Component projection
function computePca2D(matrix) {
  if (!matrix || matrix.length === 0) return [];
  const n = matrix.length;
  const d = matrix[0].length;

  // Compute column means
  const means = new Array(d).fill(0);
  for (let i = 0; i < n; i++) {
    for (let j = 0; j < d; j++) {
      means[j] += matrix[i][j];
    }
  }
  for (let j = 0; j < d; j++) means[j] /= n;

  // Center data
  const centered = matrix.map(row => row.map((val, j) => val - means[j]));

  // Approximate top 2 components using clinical variance heuristics
  // Component 1 (X axis): Major variance along Age + Metabolic/Cardio profile (BP + Cholesterol)
  // Component 2 (Y axis): Major variance along Acute Respiratory Symptoms (Fever + Cough + Breathing)
  return centered.map(row => {
    // Weights for PC1: standardized Age, BP, Cholesterol
    const x = (row[0] * 1.5) + (row[5] * 2.0) + (row[6] * 1.8) - (row[1] * 0.5);
    // Weights for PC2: Fever, Cough, Breathing, Fatigue
    const y = (row[1] * 2.2) + (row[2] * 1.8) + (row[4] * 2.5) + (row[3] * 0.8) - (row[0] * 0.4);

    return {
      x: Number(x.toFixed(2)),
      y: Number(y.toFixed(2))
    };
  });
}
