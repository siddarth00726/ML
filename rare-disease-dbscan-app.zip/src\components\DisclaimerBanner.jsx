import React from 'react';
import { AlertTriangle, ShieldCheck } from 'lucide-react';

export default function DisclaimerBanner() {
  return (
    <aside aria-label="Medical Disclaimer" className="bg-gradient-to-r from-blue-900 via-indigo-900 to-purple-900 text-white text-xs sm:text-sm py-2 px-4 shadow-sm border-b border-indigo-700/50">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <span className="p-1 bg-amber-400/20 text-amber-300 rounded-full shrink-0">
            <AlertTriangle className="w-3.5 h-3.5" />
          </span>
          <p className="leading-snug font-medium text-slate-200">
            <span className="text-amber-300 font-semibold uppercase tracking-wider text-[11px] mr-1.5">Decision-Support Notice:</span>
            This application is intended only as a machine-learning decision-support demonstration and is not a substitute for professional medical diagnosis.
          </p>
        </div>
        <div className="hidden md:flex items-center gap-1.5 text-blue-200 text-xs shrink-0 bg-white/10 px-2.5 py-0.5 rounded-full backdrop-blur-sm">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          <span>Academic Research Prototype</span>
        </div>
      </div>
    </aside>
  );
}
