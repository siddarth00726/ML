import React, { useState } from 'react';
import { 
  ScatterChart, 
  Layers, 
  AlertTriangle, 
  CheckCircle2, 
  Users, 
  Percent, 
  Sliders, 
  Info, 
  Eye, 
  Activity,
  Maximize2
} from 'lucide-react';
import ParameterControls from '../components/ParameterControls';
import { CLUSTER_PROFILES } from '../data/defaultParameters';

export default function DbscanDashboardPage({
  clusteredRecords,
  metrics,
  clustersSummary,
  eps,
  setEps,
  minPts,
  setMinPts,
  onResetParams,
  isRecalculating,
  setActivePage
}) {
  const [selectedPoint, setSelectedPoint] = useState(null);
  const [filterCluster, setFilterCluster] = useState('ALL');

  // Filtered points for scatter plot
  const visiblePoints = clusteredRecords.filter(pt => {
    if (filterCluster === 'ALL') return true;
    if (filterCluster === 'ANOMALY') return pt.isAnomaly;
    return pt.cluster.toString() === filterCluster;
  });

  // Calculate coordinates bounds for SVG scatter plot
  const xValues = clusteredRecords.map(p => p.pcaX || 0);
  const yValues = clusteredRecords.map(p => p.pcaY || 0);
  const minX = Math.min(...xValues, -5);
  const maxX = Math.max(...xValues, 5);
  const minY = Math.min(...yValues, -5);
  const maxY = Math.max(...yValues, 5);

  const padding = 1.2;
  const domainX = [minX - padding, maxX + padding];
  const domainY = [minY - padding, maxY + padding];

  const svgWidth = 640;
  const svgHeight = 420;
  const plotMargin = { top: 30, right: 30, bottom: 50, left: 60 };
  const innerWidth = svgWidth - plotMargin.left - plotMargin.right;
  const innerHeight = svgHeight - plotMargin.top - plotMargin.bottom;

  const scaleX = (val) => {
    return plotMargin.left + ((val - domainX[0]) / (domainX[1] - domainX[0])) * innerWidth;
  };

  const scaleY = (val) => {
    return plotMargin.top + innerHeight - ((val - domainY[0]) / (domainY[1] - domainY[0])) * innerHeight;
  };

  // Color mapper for clusters
  const getClusterColor = (clusterId) => {
    if (clusterId === -1) return "#ef4444"; // Red for noise/anomaly
    const colors = ["#2563eb", "#9333ea", "#06b6d4", "#10b981", "#f59e0b", "#ec4899", "#8b5cf6"];
    return colors[clusterId % colors.length];
  };

  // Age Distribution Calculation
  const ageBuckets = [
    { label: "18-29", min: 18, max: 29, count: 0, anomalies: 0 },
    { label: "30-44", min: 30, max: 44, count: 0, anomalies: 0 },
    { label: "45-59", min: 45, max: 59, count: 0, anomalies: 0 },
    { label: "60-74", min: 60, max: 74, count: 0, anomalies: 0 },
    { label: "75+", min: 75, max: 120, count: 0, anomalies: 0 }
  ];

  clusteredRecords.forEach(p => {
    const age = p.age || 40;
    const bucket = ageBuckets.find(b => age >= b.min && age <= b.max) || ageBuckets[2];
    bucket.count++;
    if (p.isAnomaly) bucket.anomalies++;
  });
  const maxAgeCount = Math.max(...ageBuckets.map(b => b.count), 1);

  // Health Feature Distribution counts
  const featureBreakdown = {
    fever: clusteredRecords.filter(p => p.fever === "Yes").length,
    cough: clusteredRecords.filter(p => p.cough === "Yes").length,
    fatigue: clusteredRecords.filter(p => p.fatigue === "Yes").length,
    dyspnea: clusteredRecords.filter(p => p.difficultyBreathing === "Yes").length,
    highBp: clusteredRecords.filter(p => (p.bloodPressure || '').toLowerCase() === "high").length,
    highChol: clusteredRecords.filter(p => (p.cholesterol || '').toLowerCase() === "high").length
  };

  // Doughnut Chart Geometry
  const total = metrics.totalPatients || 1;
  const normalAngle = (metrics.normalCases / total) * 360;
  const anomalyAngle = (metrics.numAnomalies / total) * 360;

  return (
    <div className="space-y-8 pb-12">
      
      {/* Page Header */}
      <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-50 text-purple-700 border border-purple-200 text-xs font-semibold mb-2">
            <ScatterChart className="w-3.5 h-3.5" />
            <span>Unsupervised Clustering Analytics</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900">
            DBSCAN Anomaly Detection Dashboard
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Visualizing high-dimensional density separation, cluster structures, and isolated patient records.
          </p>
        </div>

        <button
          onClick={() => setActivePage('anomalies')}
          className="px-4 py-2.5 bg-rose-50 text-rose-700 hover:bg-rose-100 border border-rose-200 rounded-xl text-xs font-bold flex items-center gap-2 transition-colors self-start sm:self-auto"
        >
          <AlertTriangle className="w-4 h-4 text-rose-600" />
          <span>Inspect {metrics.numAnomalies} Outliers</span>
        </button>
      </div>

      {/* 5 Prominent KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
        
        {/* Total Patients */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider">Total Patients</span>
            <Users className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-2xl sm:text-3xl font-black text-slate-800">
            {metrics.totalPatients}
          </div>
          <div className="text-[11px] text-slate-500 mt-1 font-medium">
            Active Dataset Records
          </div>
        </div>

        {/* Number of Clusters */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider">Clusters Formed</span>
            <Layers className="w-4 h-4 text-purple-600" />
          </div>
          <div className="text-2xl sm:text-3xl font-black text-purple-700">
            {metrics.numClusters}
          </div>
          <div className="text-[11px] text-slate-500 mt-1 font-medium">
            Dense Core Subgroups
          </div>
        </div>

        {/* Normal Cases */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider">Normal Cases</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl sm:text-3xl font-black text-emerald-600">
            {metrics.normalCases}
          </div>
          <div className="text-[11px] text-slate-500 mt-1 font-medium">
            Cluster-Reachable Cases
          </div>
        </div>

        {/* Number of Anomalies */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider">Anomalies</span>
            <AlertTriangle className="w-4 h-4 text-rose-600" />
          </div>
          <div className="text-2xl sm:text-3xl font-black text-rose-600">
            {metrics.numAnomalies}
          </div>
          <div className="text-[11px] text-rose-600/90 mt-1 font-medium">
            Potential Unusual Cases
          </div>
        </div>

        {/* Anomaly Percentage */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs col-span-2 md:col-span-1">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider">Anomaly Rate</span>
            <Percent className="w-4 h-4 text-indigo-600" />
          </div>
          <div className="text-2xl sm:text-3xl font-black text-indigo-600">
            {metrics.anomalyPercentage}%
          </div>
          <div className="text-[11px] text-slate-500 mt-1 font-medium">
            Population Outlier Ratio
          </div>
        </div>

      </div>

      {/* Parameter Controls Panel */}
      <ParameterControls
        eps={eps}
        setEps={setEps}
        minPts={minPts}
        setMinPts={setMinPts}
        onReset={onResetParams}
        isRecalculating={isRecalculating}
      />

      {/* Main Visualizations Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Column: Interactive 2D DBSCAN Scatter Plot (7 Cols) */}
        <div className="lg:col-span-7 bg-white rounded-2xl p-6 border border-slate-200 shadow-xs flex flex-col">
          
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 mb-4 border-b border-slate-100">
            <div>
              <h3 className="text-base font-bold text-slate-800 flex items-center gap-2">
                <ScatterChart className="w-4 h-4 text-blue-600" />
                <span>2D DBSCAN Spatial Cluster Projection</span>
              </h3>
              <p className="text-xs text-slate-500">
                Principal biomarker variance axes. Outliers (-1) highlighted in red.
              </p>
            </div>

            {/* Cluster Filter Select */}
            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-500 font-medium">Filter View:</span>
              <select
                value={filterCluster}
                onChange={(e) => setFilterCluster(e.target.value)}
                className="text-xs bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 font-semibold text-slate-700"
              >
                <option value="ALL">All Points ({clusteredRecords.length})</option>
                <option value="ANOMALY">Anomalies Only ({metrics.numAnomalies})</option>
                {clustersSummary.filter(c => c.clusterId !== -1).map(c => (
                  <option key={c.clusterId} value={c.clusterId.toString()}>
                    Cluster {c.clusterId} ({c.count})
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Scatter Plot SVG Canvas */}
          <div className="relative w-full overflow-x-auto">
            <svg
              viewBox={`0 0 ${svgWidth} ${svgHeight}`}
              className="w-full h-auto max-h-[460px] select-none"
            >
              {/* Plot Background */}
              <rect
                x={plotMargin.left}
                y={plotMargin.top}
                width={innerWidth}
                height={innerHeight}
                fill="#f8fafc"
                rx="8"
              />

              {/* Grid Lines */}
              {[-3, -1.5, 0, 1.5, 3].map((tick) => {
                const y = scaleY(tick);
                const x = scaleX(tick);
                return (
                  <g key={tick}>
                    <line
                      x1={plotMargin.left}
                      x2={plotMargin.left + innerWidth}
                      y1={y}
                      y2={y}
                      stroke="#e2e8f0"
                      strokeDasharray="3 3"
                    />
                    <line
                      x1={x}
                      x2={x}
                      y1={plotMargin.top}
                      y2={plotMargin.top + innerHeight}
                      stroke="#e2e8f0"
                      strokeDasharray="3 3"
                    />
                  </g>
                );
              })}

              {/* Axis Titles */}
              <text
                x={plotMargin.left + innerWidth / 2}
                y={svgHeight - 10}
                textAnchor="middle"
                className="text-[11px] fill-slate-400 font-medium"
              >
                Primary Axis 1 (Cardiometabolic &amp; Age Variation) &rarr;
              </text>

              <text
                x={18}
                y={plotMargin.top + innerHeight / 2}
                textAnchor="middle"
                transform={`rotate(-90 18 ${plotMargin.top + innerHeight / 2})`}
                className="text-[11px] fill-slate-400 font-medium"
              >
                &larr; Primary Axis 2 (Acute Respiratory Symptoms)
              </text>

              {/* Data Points */}
              {visiblePoints.map((pt, idx) => {
                const cx = scaleX(pt.pcaX || 0);
                const cy = scaleY(pt.pcaY || 0);
                const isSelected = selectedPoint && selectedPoint.id === pt.id;
                const isAnomaly = pt.isAnomaly;
                const color = getClusterColor(pt.cluster);

                return (
                  <g
                    key={pt.id || idx}
                    className="cursor-pointer transition-transform duration-150"
                    onClick={() => setSelectedPoint(pt)}
                    onMouseEnter={() => setSelectedPoint(pt)}
                  >
                    {/* Outlier Halo Effect */}
                    {isAnomaly && (
                      <circle
                        cx={cx}
                        cy={cy}
                        r={isSelected ? 14 : 10}
                        fill="rgba(239, 68, 68, 0.25)"
                        className="animate-pulse"
                      />
                    )}

                    {/* Core Point Marker */}
                    <circle
                      cx={cx}
                      cy={cy}
                      r={isAnomaly ? 6 : (isSelected ? 7 : (pt.isCore ? 5 : 4))}
                      fill={color}
                      stroke={isSelected ? "#0f172a" : (isAnomaly ? "#b91c1c" : "#ffffff")}
                      strokeWidth={isSelected ? 2.5 : (isAnomaly ? 2 : 1.2)}
                      opacity={0.92}
                    />

                    {/* Anomaly Label for severe outliers */}
                    {isAnomaly && (
                      <text
                        x={cx + 8}
                        y={cy - 4}
                        className="text-[9px] font-mono font-bold fill-rose-700 pointer-events-none"
                      >
                        {pt.id}
                      </text>
                    )}
                  </g>
                );
              })}
            </svg>
          </div>

          {/* Interactive Tooltip / Point Inspector Banner */}
          {selectedPoint ? (
            <div className="mt-4 p-3.5 bg-slate-900 text-white rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs animate-in fade-in duration-200">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="font-mono font-bold text-blue-400">{selectedPoint.id}</span>
                  <span className="text-slate-400">&bull;</span>
                  <span>{selectedPoint.age} yrs, {selectedPoint.gender}</span>
                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                    selectedPoint.isAnomaly ? 'bg-rose-500 text-white' : 'bg-emerald-600 text-white'
                  }`}>
                    {selectedPoint.isAnomaly ? "Noise / Outlier (-1)" : `Cluster ${selectedPoint.cluster}`}
                  </span>
                </div>
                <div className="text-slate-300">
                  <strong className="text-white">Condition:</strong> {selectedPoint.medicalCondition}
                </div>
              </div>

              <div className="flex items-center gap-3 shrink-0 text-right">
                <div>
                  <div className="text-[10px] text-slate-400">Anomaly Dist</div>
                  <div className="font-mono text-amber-400 font-bold">{selectedPoint.anomalyScore}</div>
                </div>
                <button
                  onClick={() => setActivePage('patient-analysis')}
                  className="px-2.5 py-1 bg-blue-600 hover:bg-blue-500 text-white rounded-md text-[11px] font-semibold transition-colors"
                >
                  Analyze &rarr;
                </button>
              </div>
            </div>
          ) : (
            <div className="mt-4 py-2 px-3 bg-slate-50 rounded-lg text-center text-xs text-slate-500 flex items-center justify-center gap-1.5">
              <Info className="w-3.5 h-3.5 text-blue-500" />
              <span>Hover or click any data point in the scatter plot to inspect its clinical profile.</span>
            </div>
          )}

          {/* Legend */}
          <div className="mt-4 pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2 text-xs">
            <div className="flex items-center gap-4 flex-wrap">
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded-full bg-rose-500 border border-rose-700 shadow-xs" />
                <span className="font-semibold text-rose-700">Cluster -1 (Outliers / Noise)</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded-full bg-blue-600" />
                <span className="text-slate-600">Cluster 0 (Respiratory)</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded-full bg-purple-600" />
                <span className="text-slate-600">Cluster 1 (Cardiometabolic)</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded-full bg-cyan-500" />
                <span className="text-slate-600">Cluster 2 (Airway/Asthma)</span>
              </div>
            </div>
            <span className="text-[11px] text-slate-400 font-mono">Distance Metric: Euclidean</span>
          </div>

        </div>

        {/* Right Column: Supplementary Charts & Breakdown (5 Cols) */}
        <div className="lg:col-span-5 space-y-6">
          
          {/* Normal vs Anomaly Doughnut Visualization */}
          <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs">
            <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wide mb-4 flex items-center justify-between">
              <span>Normal vs Anomaly Breakdown</span>
              <Percent className="w-4 h-4 text-slate-400" />
            </h3>

            <div className="flex items-center justify-center gap-6">
              
              {/* SVG Circular Doughnut */}
              <div className="relative w-36 h-36 flex items-center justify-center">
                <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                  <circle
                    cx="50"
                    cy="50"
                    r="38"
                    stroke="#e2e8f0"
                    strokeWidth="14"
                    fill="transparent"
                  />
                  {/* Normal Cases Segment */}
                  <circle
                    cx="50"
                    cy="50"
                    r="38"
                    stroke="#3b82f6"
                    strokeWidth="14"
                    strokeDasharray={`${(metrics.normalCases / total) * 238.76} 238.76`}
                    strokeDashoffset="0"
                    fill="transparent"
                    strokeLinecap="round"
                  />
                  {/* Anomaly Segment */}
                  <circle
                    cx="50"
                    cy="50"
                    r="38"
                    stroke="#ef4444"
                    strokeWidth="14"
                    strokeDasharray={`${(metrics.numAnomalies / total) * 238.76} 238.76`}
                    strokeDashoffset={`-${(metrics.normalCases / total) * 238.76}`}
                    fill="transparent"
                    strokeLinecap="round"
                  />
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
                  <span className="text-xl font-black text-slate-800">{metrics.numAnomalies}</span>
                  <span className="text-[10px] text-rose-600 font-bold uppercase">Outliers</span>
                </div>
              </div>

              {/* Legends & Percentages */}
              <div className="space-y-3 text-xs">
                <div className="p-2.5 rounded-lg bg-blue-50/70 border border-blue-100">
                  <div className="flex items-center gap-1.5 font-bold text-blue-800">
                    <span className="w-2.5 h-2.5 rounded-full bg-blue-600" />
                    <span>Conforming Cohort</span>
                  </div>
                  <div className="text-sm font-extrabold text-blue-900 mt-0.5">
                    {metrics.normalCases} cases ({(100 - parseFloat(metrics.anomalyPercentage)).toFixed(1)}%)
                  </div>
                </div>

                <div className="p-2.5 rounded-lg bg-rose-50/70 border border-rose-100">
                  <div className="flex items-center gap-1.5 font-bold text-rose-800">
                    <span className="w-2.5 h-2.5 rounded-full bg-rose-600" />
                    <span>Unusual Cases (Noise)</span>
                  </div>
                  <div className="text-sm font-extrabold text-rose-900 mt-0.5">
                    {metrics.numAnomalies} cases ({metrics.anomalyPercentage}%)
                  </div>
                </div>
              </div>

            </div>
          </div>

          {/* Cluster Membership Breakdown Bars */}
          <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs">
            <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wide mb-3 flex items-center justify-between">
              <span>Patient Distribution by Cluster</span>
              <Layers className="w-4 h-4 text-slate-400" />
            </h3>

            <div className="space-y-3">
              {clustersSummary.map((c) => (
                <div key={c.clusterId} className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className={`font-semibold ${c.isAnomaly ? 'text-rose-700' : 'text-slate-700'}`}>
                      {c.name}
                    </span>
                    <span className="font-mono text-slate-500 font-bold">
                      {c.count} pts ({c.percentage}%)
                    </span>
                  </div>
                  <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-300 ${
                        c.isAnomaly ? 'bg-rose-500' : 'bg-gradient-to-r from-blue-500 to-indigo-600'
                      }`}
                      style={{ width: `${Math.max(parseFloat(c.percentage), 4)}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Age Distribution Histogram */}
          <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs">
            <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wide mb-3 flex items-center justify-between">
              <span>Age Distribution &amp; Outliers</span>
              <Users className="w-4 h-4 text-slate-400" />
            </h3>

            <div className="space-y-2.5">
              {ageBuckets.map((b, i) => (
                <div key={i} className="flex items-center gap-3 text-xs">
                  <span className="w-12 font-medium text-slate-600 shrink-0">{b.label}</span>
                  <div className="flex-1 h-5 bg-slate-100 rounded-md overflow-hidden flex">
                    <div
                      className="bg-blue-500 h-full"
                      style={{ width: `${((b.count - b.anomalies) / maxAgeCount) * 100}%` }}
                      title={`${b.count - b.anomalies} Normal`}
                    />
                    <div
                      className="bg-rose-500 h-full"
                      style={{ width: `${(b.anomalies / maxAgeCount) * 100}%` }}
                      title={`${b.anomalies} Anomalies`}
                    />
                  </div>
                  <span className="w-10 text-right font-mono font-semibold text-slate-700 shrink-0">
                    {b.count}
                  </span>
                </div>
              ))}
            </div>
            <div className="flex items-center gap-4 text-[11px] text-slate-400 mt-3 pt-2 border-t border-slate-100">
              <span className="flex items-center gap-1">
                <span className="w-2 h-2 rounded-xs bg-blue-500" /> Normal
              </span>
              <span className="flex items-center gap-1">
                <span className="w-2 h-2 rounded-xs bg-rose-500" /> Outlier
              </span>
            </div>
          </div>

          {/* Health Biomarker Prevalence Distribution */}
          <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs">
            <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wide mb-3 flex items-center justify-between">
              <span>Health Feature Prevalence</span>
              <Activity className="w-4 h-4 text-slate-400" />
            </h3>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-200">
                <span className="text-slate-500 block">Fever Present</span>
                <span className="text-base font-extrabold text-slate-800">{featureBreakdown.fever}</span>
                <span className="text-[10px] text-slate-400 ml-1">({((featureBreakdown.fever / total) * 100).toFixed(0)}%)</span>
              </div>
              <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-200">
                <span className="text-slate-500 block">Cough Present</span>
                <span className="text-base font-extrabold text-slate-800">{featureBreakdown.cough}</span>
                <span className="text-[10px] text-slate-400 ml-1">({((featureBreakdown.cough / total) * 100).toFixed(0)}%)</span>
              </div>
              <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-200">
                <span className="text-slate-500 block">Dyspnea (Breathing)</span>
                <span className="text-base font-extrabold text-slate-800">{featureBreakdown.dyspnea}</span>
                <span className="text-[10px] text-slate-400 ml-1">({((featureBreakdown.dyspnea / total) * 100).toFixed(0)}%)</span>
              </div>
              <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-200">
                <span className="text-slate-500 block">High Blood Pressure</span>
                <span className="text-base font-extrabold text-slate-800">{featureBreakdown.highBp}</span>
                <span className="text-[10px] text-slate-400 ml-1">({((featureBreakdown.highBp / total) * 100).toFixed(0)}%)</span>
              </div>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
}
