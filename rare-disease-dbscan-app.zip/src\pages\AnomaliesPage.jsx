import React, { useState } from 'react';
import { 
  AlertOctagon, 
  Search, 
  Filter, 
  Download, 
  Eye, 
  AlertTriangle, 
  CheckCircle2, 
  X, 
  FileText, 
  ArrowUpDown,
  Stethoscope
} from 'lucide-react';

export default function AnomaliesPage({ clusteredRecords, clustersSummary, setActivePage }) {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('Anomaly'); // Default to showing anomalies
  const [clusterFilter, setClusterFilter] = useState('ALL');
  const [selectedPatient, setSelectedPatient] = useState(null);

  // Filter records
  const filteredRecords = clusteredRecords.filter(patient => {
    // Search query matches ID or Medical Condition
    const matchesSearch = 
      patient.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (patient.medicalCondition || '').toLowerCase().includes(searchTerm.toLowerCase());

    // Status filter
    let matchesStatus = true;
    if (statusFilter === 'Anomaly') matchesStatus = patient.isAnomaly;
    else if (statusFilter === 'Normal') matchesStatus = !patient.isAnomaly;

    // Cluster filter
    let matchesCluster = true;
    if (clusterFilter !== 'ALL') {
      matchesCluster = patient.cluster.toString() === clusterFilter;
    }

    return matchesSearch && matchesStatus && matchesCluster;
  });

  // Export CSV
  const handleExportCSV = () => {
    const headers = ["Patient ID", "Age", "Gender", "Symptoms", "Medical Condition", "Blood Pressure", "Cholesterol", "Cluster", "Anomaly Status", "Anomaly Score"];
    const rows = filteredRecords.map(p => [
      p.id,
      p.age,
      p.gender,
      `"${(p.symptoms || [p.fever === 'Yes' && 'Fever', p.cough === 'Yes' && 'Cough', p.difficultyBreathing === 'Yes' && 'Dyspnea']).filter(Boolean).join(', ')}"`,
      `"${(p.medicalCondition || '').replace(/"/g, '""')}"`,
      p.bloodPressure,
      p.cholesterol,
      p.cluster,
      p.status,
      p.anomalyScore
    ]);

    const csvContent = "data:text/csv;charset=utf-8," + [headers.join(","), ...rows.map(e => e.join(","))].join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `dbscan_patient_anomalies_${statusFilter.toLowerCase()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-8 pb-12">
      
      {/* Page Header */}
      <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-50 text-rose-700 border border-rose-200 text-xs font-semibold mb-2">
            <AlertOctagon className="w-3.5 h-3.5" />
            <span>Density-Based Outlier Surveillance</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900">
            Identified Anomaly &amp; Unusual Case Records
          </h1>
          <p className="text-sm text-slate-500 mt-1 max-w-2xl">
            Records classified with Cluster ID = -1 possess insufficient local neighborhood point density, indicating rare biomarker and symptom constellations.
          </p>
        </div>

        <button
          onClick={handleExportCSV}
          className="px-4 py-2.5 bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 rounded-xl text-xs font-semibold flex items-center gap-2 transition-colors self-start md:self-auto shadow-xs"
        >
          <Download className="w-4 h-4 text-slate-500" />
          <span>Export Filtered CSV ({filteredRecords.length})</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-12 gap-4">
          
          {/* Search Box */}
          <div className="sm:col-span-5 relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search by Patient ID or Condition..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-500"
            />
          </div>

          {/* Status Filter Buttons */}
          <div className="sm:col-span-4 flex items-center gap-1.5 bg-slate-100 p-1 rounded-xl">
            {['Anomaly', 'Normal', 'All'].map((tab) => (
              <button
                key={tab}
                onClick={() => setStatusFilter(tab)}
                className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all ${
                  statusFilter === tab
                    ? tab === 'Anomaly'
                      ? 'bg-rose-600 text-white shadow-xs'
                      : 'bg-white text-slate-800 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {tab === 'Anomaly' ? 'Anomalies' : tab}
              </button>
            ))}
          </div>

          {/* Cluster Dropdown Filter */}
          <div className="sm:col-span-3">
            <select
              value={clusterFilter}
              onChange={(e) => setClusterFilter(e.target.value)}
              className="w-full px-3 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-500 font-medium"
            >
              <option value="ALL">All Clusters</option>
              <option value="-1">Noise / Outliers (Cluster -1)</option>
              {clustersSummary.filter(c => c.clusterId !== -1).map(c => (
                <option key={c.clusterId} value={c.clusterId.toString()}>
                  {c.name} ({c.count})
                </option>
              ))}
            </select>
          </div>

        </div>

        {/* Active Filters Summary Indicator */}
        <div className="flex items-center justify-between text-xs text-slate-500 pt-1">
          <div>
            Showing <span className="font-bold text-slate-800">{filteredRecords.length}</span> patient records
            {statusFilter !== 'All' && <span> with status: <strong className="text-slate-700">{statusFilter}</strong></span>}
          </div>
          {(searchTerm || statusFilter !== 'Anomaly' || clusterFilter !== 'ALL') && (
            <button
              onClick={() => {
                setSearchTerm('');
                setStatusFilter('All');
                setClusterFilter('ALL');
              }}
              className="text-xs text-blue-600 hover:underline font-medium"
            >
              Reset All Filters
            </button>
          )}
        </div>
      </div>

      {/* Anomaly Detection Records Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/80 border-b border-slate-200 text-[11px] font-bold text-slate-600 uppercase tracking-wider">
                <th className="py-3.5 px-4 sm:px-6">Patient ID</th>
                <th className="py-3.5 px-3">Age</th>
                <th className="py-3.5 px-4">Symptoms</th>
                <th className="py-3.5 px-4">Medical Condition</th>
                <th className="py-3.5 px-3">Cluster</th>
                <th className="py-3.5 px-4">Status</th>
                <th className="py-3.5 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-xs text-slate-700">
              {filteredRecords.length > 0 ? (
                filteredRecords.map((patient) => {
                  const isAnomaly = patient.isAnomaly;
                  const symptomList = patient.symptoms 
                    ? patient.symptoms.join(', ')
                    : [
                        patient.fever === 'Yes' && 'Fever',
                        patient.cough === 'Yes' && 'Cough',
                        patient.fatigue === 'Yes' && 'Fatigue',
                        patient.difficultyBreathing === 'Yes' && 'Dyspnea'
                      ].filter(Boolean).join(', ') || 'None';

                  return (
                    <tr 
                      key={patient.id} 
                      className={`hover:bg-slate-50/80 transition-colors ${
                        isAnomaly ? 'bg-rose-50/30' : ''
                      }`}
                    >
                      {/* Patient ID */}
                      <td className="py-3.5 px-4 sm:px-6 font-mono font-bold text-slate-900">
                        {patient.id}
                      </td>

                      {/* Age */}
                      <td className="py-3.5 px-3 font-semibold text-slate-700">
                        {patient.age} yrs
                      </td>

                      {/* Symptoms */}
                      <td className="py-3.5 px-4 max-w-xs truncate text-slate-600">
                        {symptomList}
                      </td>

                      {/* Medical Condition */}
                      <td className="py-3.5 px-4 font-medium text-slate-800">
                        {patient.medicalCondition || 'Unspecified'}
                      </td>

                      {/* Cluster */}
                      <td className="py-3.5 px-3 font-mono">
                        {patient.cluster === -1 ? (
                          <span className="px-2 py-0.5 rounded-md text-[11px] font-bold bg-rose-100 text-rose-800 border border-rose-200">
                            -1 (Noise)
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded-md text-[11px] font-bold bg-blue-50 text-blue-700 border border-blue-200">
                            Cluster {patient.cluster}
                          </span>
                        )}
                      </td>

                      {/* Status */}
                      <td className="py-3.5 px-4">
                        {isAnomaly ? (
                          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold bg-rose-100 text-rose-800 border border-rose-200">
                            <AlertTriangle className="w-3 h-3 text-rose-600" />
                            <span>Anomaly Detected</span>
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
                            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                            <span>Normal Pattern</span>
                          </span>
                        )}
                      </td>

                      {/* Actions */}
                      <td className="py-3.5 px-4 text-right">
                        <button
                          onClick={() => setSelectedPatient(patient)}
                          className="px-2.5 py-1 text-xs font-semibold text-blue-600 hover:text-blue-800 hover:bg-blue-50 rounded-lg transition-colors inline-flex items-center gap-1"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          <span>Inspect</span>
                        </button>
                      </td>
                    </tr>
                  );
                })
              ) : (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-400">
                    <p className="text-sm font-medium">No patient records match the selected filter criteria.</p>
                    <button
                      onClick={() => { setSearchTerm(''); setStatusFilter('All'); setClusterFilter('ALL'); }}
                      className="mt-2 text-xs text-blue-600 hover:underline font-semibold"
                    >
                      Clear Filters
                    </button>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Patient Detail Inspection Modal */}
      {selectedPatient && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl max-w-xl w-full p-6 sm:p-8 shadow-2xl border border-slate-200 relative max-h-[90vh] overflow-y-auto">
            
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                  selectedPatient.isAnomaly ? 'bg-rose-100 text-rose-700' : 'bg-blue-100 text-blue-700'
                }`}>
                  <Stethoscope className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                    <span>Patient Profile: {selectedPatient.id}</span>
                  </h3>
                  <p className="text-xs text-slate-500">
                    Age {selectedPatient.age} &bull; {selectedPatient.gender}
                  </p>
                </div>
              </div>

              <button
                onClick={() => setSelectedPatient(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Anomaly Status Banner */}
            <div className={`mt-5 p-4 rounded-xl border ${
              selectedPatient.isAnomaly 
                ? 'bg-rose-50 border-rose-200 text-rose-900' 
                : 'bg-emerald-50 border-emerald-200 text-emerald-900'
            }`}>
              <div className="flex items-start gap-3">
                {selectedPatient.isAnomaly ? (
                  <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
                ) : (
                  <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                )}
                <div>
                  <h4 className="font-bold text-sm">
                    {selectedPatient.isAnomaly 
                      ? "Potential unusual case detected — further medical examination recommended." 
                      : "Clinical presentation conforms to established population clusters."}
                  </h4>
                  <p className="text-xs mt-1 opacity-90">
                    Cluster Status: {selectedPatient.cluster === -1 ? 'Isolated Spatial Noise (-1)' : `Core Cohort #${selectedPatient.cluster}`} &bull; Anomaly Score: {selectedPatient.anomalyScore}
                  </p>
                </div>
              </div>
            </div>

            {/* Diagnostic Information */}
            <div className="mt-5 space-y-3 text-xs">
              <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                <div className="font-bold text-slate-800 uppercase tracking-wide text-[11px]">
                  Clinical Condition &amp; Biomarkers
                </div>
                <div className="text-sm font-semibold text-slate-900">
                  {selectedPatient.medicalCondition}
                </div>
                <div className="grid grid-cols-2 gap-2 text-slate-600 pt-1">
                  <div>Blood Pressure: <strong className="text-slate-800">{selectedPatient.bloodPressure}</strong></div>
                  <div>Cholesterol: <strong className="text-slate-800">{selectedPatient.cholesterol}</strong></div>
                  <div>Outcome Variable: <strong className="text-slate-800">{selectedPatient.testResult}</strong></div>
                  <div>Local Point Density: <strong className="text-slate-800">{selectedPatient.isCore ? "Core Point" : "Border / Outlier"}</strong></div>
                </div>
              </div>

              {selectedPatient.medicalHistory && (
                <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200">
                  <div className="font-bold text-slate-800 uppercase tracking-wide text-[11px] mb-1">
                    Medical History &amp; Clinical Notes
                  </div>
                  <p className="text-slate-600 leading-relaxed">
                    {selectedPatient.medicalHistory}
                  </p>
                </div>
              )}
            </div>

            {/* Disclaimer & Footer */}
            <div className="mt-6 pt-4 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
              <p className="text-[11px] text-slate-400">
                Decision-support advisory only. Does not replace physician diagnosis.
              </p>
              <button
                onClick={() => setSelectedPatient(null)}
                className="px-4 py-2 bg-slate-900 text-white rounded-lg font-semibold hover:bg-slate-800 self-end"
              >
                Close Inspection
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
