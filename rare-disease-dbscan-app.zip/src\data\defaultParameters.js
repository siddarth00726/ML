export const DEFAULT_DBSCAN_PARAMS = {
  eps: 1.30,
  minPts: 4,
  metric: 'euclidean',
  features: [
    'standardizedAge',
    'feverVal',
    'coughVal',
    'fatigueVal',
    'breathingVal',
    'bpVal',
    'cholVal',
    'outcomeVal'
  ]
};

export const PREPROCESSING_STEPS = [
  {
    step: 1,
    name: "Remove duplicate records",
    description: "Scan the patient database for identical demographic and clinical records to prevent artificial density inflation."
  },
  {
    step: 2,
    name: "Handle missing values",
    description: "Impute missing clinical features using median for numerical values (Age) and mode for categorical symptoms/vitals."
  },
  {
    step: 3,
    name: "Correct data types",
    description: "Ensure numeric parsing of Age and binary/ordinal mapping for categorical clinical inputs."
  },
  {
    step: 4,
    name: "Encode categorical values",
    description: "Map binary symptoms (Fever, Cough, Fatigue, Difficulty Breathing: Yes=1, No=0), Blood Pressure (Normal=0, High=1), Cholesterol (Normal=0, High=1), Outcome (Positive=1, Negative=0)."
  },
  {
    step: 5,
    name: "Check invalid values",
    description: "Validate biological plausibility ranges (e.g., Age 1-120, positive blood pressures)."
  },
  {
    step: 6,
    name: "Select relevant features",
    description: "Retain high-variance clinical parameters that define disease signatures while pruning administrative identifiers."
  },
  {
    step: 7,
    name: "Standardize numerical features",
    description: "Apply Z-Score Standardization (StandardScaler: z = (x - mean) / std) to ensure Euclidean distances in DBSCAN are not dominated by the scale of Age."
  }
];

export const CLUSTER_PROFILES = {
  "-1": {
    name: "Potential Unusual Case (Anomaly/Noise)",
    color: "#ef4444",
    badgeBg: "bg-rose-100 text-rose-800 border-rose-200",
    description: "Isolated outlier record with low local point density; diverges significantly from common clinical symptom presentations. Recommended for clinical case conference."
  },
  "0": {
    name: "Cluster 0: Viral Respiratory Cohort",
    color: "#3b82f6",
    badgeBg: "bg-blue-100 text-blue-800 border-blue-200",
    description: "Dense group exhibiting acute upper/lower respiratory symptoms (fever, cough, fatigue) with normal baseline blood pressure and cholesterol."
  },
  "1": {
    name: "Cluster 1: Cardiometabolic Cohort",
    color: "#8b5cf6",
    badgeBg: "bg-purple-100 text-purple-800 border-purple-200",
    description: "Older adult demographic displaying elevated/high blood pressure, hypercholesterolemia, and chronic fatigue without acute fever/cough."
  },
  "2": {
    name: "Cluster 2: Obstructive Pulmonary Profile",
    color: "#06b6d4",
    badgeBg: "bg-cyan-100 text-cyan-800 border-cyan-200",
    description: "Patients with predominant airway hyperresponsiveness and dyspnea (difficulty breathing, chronic cough) with normal metabolic markers."
  },
  "3": {
    name: "Cluster 3: Healthy Baseline / Low Symptom",
    color: "#10b981",
    badgeBg: "bg-emerald-100 text-emerald-800 border-emerald-200",
    description: "Reference cohort with no notable acute symptoms, normal blood pressure, normal cholesterol, and negative test findings."
  },
  "4": {
    name: "Cluster 4: Geriatric Cardiopulmonary Multi-condition",
    color: "#f59e0b",
    badgeBg: "bg-amber-100 text-amber-800 border-amber-200",
    description: "Combined chronic respiratory and cardiovascular markers in older cohorts."
  }
};
