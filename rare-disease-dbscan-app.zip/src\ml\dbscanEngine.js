// DBSCAN (Density-Based Spatial Clustering of Applications with Noise) Implementation
// Implements core point detection, density connectivity, cluster expansion, and noise (anomaly) identification.

export function euclideanDistance(a, b) {
  let sum = 0;
  for (let i = 0; i < a.length; i++) {
    const diff = a[i] - b[i];
    sum += diff * diff;
  }
  return Math.sqrt(sum);
}

export function runDBSCAN(records, featureMatrix, eps = 1.30, minPts = 4) {
  const n = featureMatrix.length;
  if (n === 0) {
    return {
      clusteredRecords: [],
      corePointIndices: [],
      metrics: {
        totalPatients: 0,
        numClusters: 0,
        numAnomalies: 0,
        normalCases: 0,
        anomalyPercentage: "0.0"
      },
      clustersSummary: []
    };
  }

  // Precompute pairwise distances
  const distanceMatrix = Array.from({ length: n }, () => new Float32Array(n));
  for (let i = 0; i < n; i++) {
    for (let j = i + 1; j < n; j++) {
      const d = euclideanDistance(featureMatrix[i], featureMatrix[j]);
      distanceMatrix[i][j] = d;
      distanceMatrix[j][i] = d;
    }
  }

  // Identify eps-neighborhood for each point
  const neighbors = Array.from({ length: n }, () => []);
  const isCore = new Uint8Array(n);
  const corePointIndices = [];

  for (let i = 0; i < n; i++) {
    for (let j = 0; j < n; j++) {
      if (distanceMatrix[i][j] <= eps) {
        neighbors[i].push(j);
      }
    }
    if (neighbors[i].length >= minPts) {
      isCore[i] = 1;
      corePointIndices.push(i);
    }
  }

  // Cluster assignment:
  // -2 = unvisited
  // -1 = noise / anomaly
  // >= 0 = cluster index
  const clusterAssignments = new Int32Array(n).fill(-2);
  let currentCluster = 0;

  for (let i = 0; i < n; i++) {
    if (clusterAssignments[i] !== -2) continue;

    // If point is not a core point, tentatively mark as noise
    if (!isCore[i]) {
      clusterAssignments[i] = -1;
      continue;
    }

    // Point i is a core point; start a new cluster and expand
    clusterAssignments[i] = currentCluster;
    const queue = [...neighbors[i]];

    let head = 0;
    while (head < queue.length) {
      const neighborIdx = queue[head++];

      // If neighbor was noise, border point joins cluster
      if (clusterAssignments[neighborIdx] === -1) {
        clusterAssignments[neighborIdx] = currentCluster;
      }

      // If not yet visited
      if (clusterAssignments[neighborIdx] === -2) {
        clusterAssignments[neighborIdx] = currentCluster;

        // If neighbor is also a core point, expand neighborhood
        if (isCore[neighborIdx]) {
          for (const nextNeighbor of neighbors[neighborIdx]) {
            if (!queue.includes(nextNeighbor)) {
              queue.push(nextNeighbor);
            }
          }
        }
      }
    }

    currentCluster++;
  }

  // Calculate Anomaly Score for each point
  // Anomaly score: minimum Euclidean distance to ANY core point in the dataset
  // If point is core or in cluster, score is small (typically <= eps)
  // If point is isolated noise, score is > eps
  const anomalyScores = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    if (corePointIndices.length === 0) {
      anomalyScores[i] = 1.0;
      continue;
    }

    let minCoreDist = Infinity;
    for (const coreIdx of corePointIndices) {
      const d = distanceMatrix[i][coreIdx];
      if (d < minCoreDist) minCoreDist = d;
    }
    // Normalize score between 0.1 and 3.5 for UI display
    anomalyScores[i] = Number(minCoreDist.toFixed(3));
  }

  // Build annotated records
  let anomaliesCount = 0;
  const clusteredRecords = records.map((rec, idx) => {
    const cluster = clusterAssignments[idx];
    const isAnomaly = cluster === -1;
    if (isAnomaly) anomaliesCount++;

    return {
      ...rec,
      cluster,
      isCore: isCore[idx] === 1,
      isAnomaly,
      status: isAnomaly ? "Anomaly Detected" : "Normal Pattern",
      anomalyScore: anomalyScores[idx],
      coreDistance: anomalyScores[idx]
    };
  });

  const totalPatients = n;
  const normalCases = totalPatients - anomaliesCount;
  const anomalyPercentage = totalPatients > 0 ? ((anomaliesCount / totalPatients) * 100).toFixed(1) : "0.0";

  // Build cluster breakdown summary
  const clustersSummary = [];
  // Noise entry
  clustersSummary.push({
    clusterId: -1,
    name: "Noise / Outliers (Potential Unusual Cases)",
    count: anomaliesCount,
    percentage: ((anomaliesCount / totalPatients) * 100).toFixed(1),
    isAnomaly: true
  });

  for (let c = 0; c < currentCluster; c++) {
    const count = clusteredRecords.filter(r => r.cluster === c).length;
    clustersSummary.push({
      clusterId: c,
      name: `Cluster ${c}`,
      count,
      percentage: ((count / totalPatients) * 100).toFixed(1),
      isAnomaly: false
    });
  }

  return {
    clusteredRecords,
    corePointIndices,
    metrics: {
      totalPatients,
      numClusters: currentCluster,
      numAnomalies: anomaliesCount,
      normalCases,
      anomalyPercentage
    },
    clustersSummary,
    params: { eps, minPts }
  };
}
